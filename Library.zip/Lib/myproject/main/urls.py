from django.urls import path
from . import views
from .backend.user_views import (
    login_view, register, logout_view, profile, staff_login, staff_dashboard, analytics,
    staff_books_management, staff_borrowings_management, staff_returns_management,
    register_borrower, process_borrowing, process_return, add_book, edit_book, delete_book,
    staff_borrowers_management, edit_borrower, delete_borrower, edit_borrowing, delete_borrowing, view_borrower, view_book, view_borrowing,
    staff_reservations_management, view_reservation, edit_reservation, delete_reservation
)
from .backend.book_views import (
    book_list, book_detail, borrow_book, return_book,
    reserve_book, cancel_reservation, borrowing_history,
    upload_books_csv
)
from .backend.bookmark_views import (
    add_bookmark, remove_bookmark, bookmark_list
)
from .views import home, qr_scan_view, api_borrowing_detail, api_return_book, show_borrowing_qrcode, upload_returns_csv

urlpatterns = [
    path('', home, name='home'),
    path('login/', login_view, name='login'),
    path('register/', register, name='register'),
    path('logout/', logout_view, name='logout'),
    path('profile/', profile, name='profile'),
    
    # Staff URLs
    path('staff/login/', staff_login, name='staff_login'),
    path('staff/dashboard/', staff_dashboard, name='staff_dashboard'),
    path('staff/analytics/', analytics, name='analytics'),
    path('staff/books/', staff_books_management, name='book'),
    path('staff/books/add/', add_book, name='add_book'),
    path('staff/books/<int:book_id>/edit/', edit_book, name='edit_book'),
    path('staff/books/<int:book_id>/delete/', delete_book, name='delete_book'),
    path('staff/books/<int:book_id>/', view_book, name='view_book'),
    path('staff/books/upload-csv/', upload_books_csv, name='upload_books_csv'),
    path('staff/borrowers/', staff_borrowers_management, name='borrowers'),
    path('staff/borrowers/register/', register_borrower, name='register_borrower'),
    path('staff/borrowers/<int:borrower_id>/', view_borrower, name='view_borrower'),
    path('staff/borrowers/<int:borrower_id>/edit/', edit_borrower, name='edit_borrower'),
    path('staff/borrowers/<int:borrower_id>/delete/', delete_borrower, name='delete_borrower'),
    path('staff/borrowings/', staff_borrowings_management, name='borrowing'),
    path('staff/borrowings/<int:borrowing_id>/', view_borrowing, name='view_borrowing'),
    path('staff/borrowings/<int:borrowing_id>/edit/', edit_borrowing, name='edit_borrowing'),
    path('staff/borrowings/<int:borrowing_id>/delete/', delete_borrowing, name='delete_borrowing'),
    path('staff/returns/', staff_returns_management, name='return'),
    path('staff/returns/upload-csv/', upload_returns_csv, name='upload_returns_csv'),
    path('staff/process-borrowing/', process_borrowing, name='process_borrowing'),
    path('staff/process-return/<int:borrowing_id>/', process_return, name='process_return'),
    path('staff/process-return/', process_return, name='process_return_general'),
    path('staff/reservations/', staff_reservations_management, name='reservations'),
    path('staff/reservations/<int:pk>/view/', view_reservation, name='view_reservation'),
    path('staff/reservations/<int:pk>/edit/', edit_reservation, name='edit_reservation'),
    path('staff/reservations/<int:pk>/delete/', delete_reservation, name='delete_reservation'),
    path('staff/qr_scan/', qr_scan_view, name='qr_scan'),
    path('api/borrowing/<int:borrowing_id>/', api_borrowing_detail, name='api_borrowing_detail'),
    path('api/return_book/<int:borrowing_id>/', api_return_book, name='api_return_book'),
    path('api/confirm-borrow/<int:borrowing_id>/', views.api_confirm_borrow, name='api_confirm_borrow'),
    
    # Book URLs (for regular users, if applicable)
    path('books/', book_list, name='book_list'),
    path('books/<int:book_id>/', book_detail, name='book_detail'),
    path('books/<int:book_id>/borrow/', borrow_book, name='borrow_book'),
    path('books/borrowings/<int:borrowing_id>/return/', return_book, name='return_book'),
    path('books/<int:book_id>/reserve/', reserve_book, name='reserve_book'),
    path('reservations/<int:reservation_id>/cancel/', cancel_reservation, name='cancel_reservation'),
    path('borrowing-history/', borrowing_history, name='borrowing_history'),
    
    # Bookmark URLs
    path('books/<int:book_id>/bookmark/', add_bookmark, name='add_bookmark'),
    path('books/<int:book_id>/unbookmark/', remove_bookmark, name='remove_bookmark'),
    path('bookmarks/', bookmark_list, name='bookmark_list'),
    path('show_borrowing_qrcode/<int:borrowing_id>/', show_borrowing_qrcode, name='show_borrowing_qrcode'),
]
