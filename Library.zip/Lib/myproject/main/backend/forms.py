from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from ..models import Borrower, Book, Borrowing, Reservation
from django.core.exceptions import ValidationError
from django.utils import timezone

class CustomUserCreationForm(UserCreationForm):
    USER_TYPE_CHOICES = [('', '------')] + list(Borrower.USER_TYPE_CHOICES)
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={'class': 'form-control'}))
    first_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    last_name = forms.CharField(required=True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    user_type = forms.ChoiceField(choices=USER_TYPE_CHOICES, required=True, widget=forms.Select(attrs={'class': 'form-select'}))
    id_number = forms.CharField(required=True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    phone_number = forms.CharField(required=True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    address = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 3}), required=True)
    
    # Student-specific fields
    year_level = forms.ChoiceField(
        choices=[('', 'Select year level')] + [(str(i), f'{i}st Year') for i in range(1, 5)],
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    section = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-control'}))
    course = forms.ChoiceField(
        choices=[
            ('', 'Select course'),
            ('BSIT', 'BSIT - Bachelor of Science in Information Technology'),
            ('BSCS', 'BSCS - Bachelor of Science in Computer Science'),
            ('BSCE', 'BSCE - Bachelor of Science in Computer Engineering'),
            ('BSEE', 'BSEE - Bachelor of Science in Electrical Engineering'),
            ('BSChem', 'BSChem - Bachelor of Science in Chemical Engineering'),
        ],
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    
    # Staff/Teacher-specific fields
    department = forms.ChoiceField(
        choices=[
            ('', 'Select department'),
            ('IT', 'Information Technology'),
            ('CS', 'Computer Science'),
            ('CE', 'Computer Engineering'),
            ('EE', 'Electrical Engineering'),
            ('Chem', 'Chemical Engineering'),
            ('Admin', 'Administration'),
        ],
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'})
    )

    class Meta:
        model = User
        fields = ('email', 'first_name', 'last_name', 'password1', 'password2')

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError('This email address is already in use.')
        return email

    def clean_id_number(self):
        id_number = self.cleaned_data.get('id_number')
        if Borrower.objects.filter(id_number=id_number).exists():
            raise forms.ValidationError('This ID number is already registered.')
        return id_number

    def clean(self):
        cleaned_data = super().clean()
        user_type = cleaned_data.get('user_type')
        
        if user_type == 'STUDENT':
            # Validate student-specific fields
            if not cleaned_data.get('year_level'):
                self.add_error('year_level', 'Year level is required for students.')
            if not cleaned_data.get('section'):
                self.add_error('section', 'Section is required for students.')
            if not cleaned_data.get('course'):
                self.add_error('course', 'Course is required for students.')
        elif user_type in ['TEACHER', 'STAFF']:
            # Validate staff/teacher-specific fields
            if not cleaned_data.get('department'):
                self.add_error('department', 'Department is required for staff/teachers.')
        
        return cleaned_data

    def save(self, commit=True):
        try:
            user = super().save(commit=False)
            user.email = self.cleaned_data['email']
            user.username = self.cleaned_data['email']  # Use email as username
            user.first_name = self.cleaned_data['first_name']
            user.last_name = self.cleaned_data['last_name']
            
            if commit:
                user.save()
                # Create borrower profile with conditional fields
                borrower_data = {
                    'user': user,
                    'user_type': self.cleaned_data['user_type'],
                    'id_number': self.cleaned_data['id_number'],
                    'phone_number': self.cleaned_data['phone_number'],
                    'address': self.cleaned_data['address'],
                }
                
                # Add student-specific fields if user is a student
                if self.cleaned_data['user_type'] == 'STUDENT':
                    borrower_data.update({
                        'year_level': self.cleaned_data['year_level'],
                        'section': self.cleaned_data['section'],
                        'course': self.cleaned_data['course'],
                    })
                # Add department for staff/teachers
                elif self.cleaned_data['user_type'] in ['TEACHER', 'STAFF']:
                    borrower_data['department'] = self.cleaned_data['department']
                
                Borrower.objects.create(**borrower_data)
            return user
        except Exception as e:
            # If there's an error, delete the user if it was created
            if 'user' in locals() and user.id:
                user.delete()
            raise e


class BorrowerEditForm(forms.ModelForm):
    email = forms.EmailField(required=True,
                             widget=forms.EmailInput(attrs={'class': 'form-control'}))
    first_name = forms.CharField(required=True, max_length=150,
                                 widget=forms.TextInput(attrs={'class': 'form-control'}))
    last_name = forms.CharField(required=True, max_length=150,
                                widget=forms.TextInput(attrs={'class': 'form-control'}))

    year_level = forms.ChoiceField(
        choices=[('', 'Select year level')] + [(str(i), f'{i}st Year') for i in range(1, 5)],
        required=False, # Set to False here, will be conditionally set in clean/init
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    section = forms.CharField(required=False,
                              widget=forms.TextInput(attrs={'class': 'form-control'}))
    course = forms.ChoiceField(
        choices=[
            ('', 'Select course'),
            ('BSIT', 'BSIT - Bachelor of Science in Information Technology'),
            ('BSCS', 'BSCS - Bachelor of Science in Computer Science'),
            ('BSCE', 'BSCE - Bachelor of Science in Computer Engineering'),
            ('BSEE', 'BSEE - Bachelor of Science in Electrical Engineering'),
            ('BSChem', 'BSChem - Bachelor of Science in Chemical Engineering'),
        ],
        required=False, # Set to False here, will be conditionally set in clean/init
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    department = forms.ChoiceField(
        choices=[('', 'Select department'),
            ('IT', 'Information Technology'),
            ('CS', 'Computer Science'),
            ('CE', 'Computer Engineering'),
            ('EE', 'Electrical Engineering'),
            ('Chem', 'Chemical Engineering'),
            ('Admin', 'Administration'),
        ],
        required=False, # Set to False here, will be conditionally set in clean/init
        widget=forms.Select(attrs={'class': 'form-select'})
    )

    class Meta:
        model = Borrower
        fields = [
            'user_type', 'id_number', 'phone_number', 'address',
            'is_active'
        ]
        widgets = {
            'user_type': forms.Select(attrs={'class': 'form-select'}),
            'id_number': forms.TextInput(attrs={'class': 'form-control'}),
            'phone_number': forms.TextInput(attrs={'class': 'form-control'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.user:
            self.fields['email'].initial = self.instance.user.email
            self.fields['first_name'].initial = self.instance.user.first_name
            self.fields['last_name'].initial = self.instance.user.last_name
        
        # Initialize student/teacher/staff specific fields from instance
        # And ensure non-applicable fields are cleared on initial load
        student_fields = ['year_level', 'section', 'course']
        staff_teacher_fields = ['department']

        if self.instance:
            user_type = self.instance.user_type
            if user_type == 'STUDENT':
                self.fields['year_level'].initial = self.instance.year_level
                self.fields['section'].initial = self.instance.section
                self.fields['course'].initial = self.instance.course
                # Clear others
                self.fields['department'].initial = ''
            elif user_type in ['TEACHER', 'STAFF']:
                self.fields['department'].initial = self.instance.department
                # Clear others
                self.fields['year_level'].initial = ''
                self.fields['section'].initial = ''
                self.fields['course'].initial = ''
            else: # For any other user type, clear all type-specific fields
                for field_name in student_fields + staff_teacher_fields:
                    self.fields[field_name].initial = ''
        else: # For a new form (though this is an edit form, good practice)
             for field_name in student_fields + staff_teacher_fields:
                 self.fields[field_name].initial = ''

        # Set required status based on user type (initial value)
        current_user_type = self.initial.get('user_type') or (self.instance.user_type if self.instance else '')
        self._set_conditional_fields_required(current_user_type)

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exclude(pk=self.instance.user.pk).exists():
            raise forms.ValidationError('This email address is already in use by another user.')
        return email

    def clean_id_number(self):
        id_number = self.cleaned_data.get('id_number')
        if Borrower.objects.filter(id_number=id_number).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError('This ID number is already registered for another borrower.')
        return id_number

    def clean(self):
        cleaned_data = super().clean()
        user_type = cleaned_data.get('user_type')

        # Set required status based on submitted user type
        self._set_conditional_fields_required(user_type)

        # Conditionally clear data for non-applicable fields in cleaned_data
        student_fields = ['year_level', 'section', 'course']
        staff_teacher_fields = ['department']

        if user_type != 'STUDENT':
            for field_name in student_fields:
                if field_name in cleaned_data: # Only clear if it was submitted
                    cleaned_data[field_name] = '';
        if user_type not in ['TEACHER', 'STAFF']:
            for field_name in staff_teacher_fields:
                if field_name in cleaned_data: # Only clear if it was submitted
                    cleaned_data[field_name] = '';

        # Re-check required fields based on the *current* cleaned_data after clearing
        if user_type == 'STUDENT':
            if not cleaned_data.get('year_level'):
                self.add_error('year_level', 'Year level is required for students.')
            if not cleaned_data.get('section'):
                self.add_error('section', 'Section is required for students.')
            if not cleaned_data.get('course'):
                self.add_error('course', 'Course is required for students.')
        elif user_type in ['TEACHER', 'STAFF']:
            if not cleaned_data.get('department'):
                self.add_error('department', 'Department is required for staff/teachers.')
        return cleaned_data

    def _set_conditional_fields_required(self, user_type):
        student_fields = ['year_level', 'section', 'course']
        staff_teacher_fields = ['department']

        for field_name in student_fields:
            self.fields[field_name].required = (user_type == 'STUDENT')
        
        for field_name in staff_teacher_fields:
            self.fields[field_name].required = (user_type in ['TEACHER', 'STAFF'])

    def save(self, commit=True):
        borrower = super().save(commit=False)
        user = borrower.user
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']

        # Conditionally save student/teacher/staff specific fields (already handled by clean method clearing)
        # We just need to assign the values from cleaned_data, which will be '' if not applicable.
        borrower.year_level = self.cleaned_data.get('year_level', '')
        borrower.section = self.cleaned_data.get('section', '')
        borrower.course = self.cleaned_data.get('course', '')
        borrower.department = self.cleaned_data.get('department', '')

        if commit:
            user.save()
            borrower.save()
        return borrower 

class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = ['book', 'borrower', 'pickup_date', 'expiry_date', 'is_fulfilled', 'is_expired']
        widgets = {
            'pickup_date': forms.DateTimeInput(attrs={'type': 'datetime-local', 'class': 'form-control'}),
            'expiry_date': forms.DateTimeInput(attrs={'type': 'datetime-local', 'class': 'form-control'}),
            'book': forms.Select(attrs={'class': 'form-control'}),
            'borrower': forms.Select(attrs={'class': 'form-control'}),
            'is_fulfilled': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'is_expired': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name in self.fields:
            if field_name not in ['is_fulfilled', 'is_expired']:
                self.fields[field_name].widget.attrs.update({'class': 'form-control'}) 

class BookForm(forms.ModelForm):
    cover_image_url = forms.CharField(
        label='Cover Image URL',
        required=False,
        widget=forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'Paste image URL here'})
    )

    class Meta:
        model = Book
        fields = '__all__'

    def save(self, commit=True):
        instance = super().save(commit=False)
        cover_image_url = self.cleaned_data.get('cover_image_url')
        if cover_image_url:
            instance.cover_image_url = cover_image_url
            if not self.cleaned_data.get('cover_image'):
                instance.cover_image = None  # Ensure file field is empty if only using URL
        if commit:
            instance.save()
        return instance 