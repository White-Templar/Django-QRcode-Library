from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.utils import timezone
from ..models import Book, Bookmark

@login_required
def add_bookmark(request, book_id):
    """View for adding a book to user's bookmarks"""
    book = get_object_or_404(Book, id=book_id)
    
    # Check if bookmark already exists
    if Bookmark.objects.filter(user=request.user, book=book).exists():
        messages.info(request, f'{book.title} is already in your bookmarks.')
        return redirect('book_detail', book_id=book.id)
    
    # Create new bookmark
    Bookmark.objects.create(
        user=request.user,
        book=book
    )
    
    messages.success(request, f'{book.title} has been added to your bookmarks.')
    return redirect('book_detail', book_id=book.id)

@login_required
def remove_bookmark(request, book_id):
    """View for removing a book from user's bookmarks"""
    book = get_object_or_404(Book, id=book_id)
    
    try:
        bookmark = Bookmark.objects.get(user=request.user, book=book)
        bookmark.delete()
        messages.success(request, f'{book.title} has been removed from your bookmarks.')
    except Bookmark.DoesNotExist:
        messages.info(request, f'{book.title} is not in your bookmarks.')
    
    return redirect('book_detail', book_id=book.id)

@login_required
def bookmark_list(request):
    """View for displaying user's bookmarked books"""
    bookmarks = Bookmark.objects.filter(user=request.user).order_by('-date_added')
    
    return render(request, 'main/bookmark_list.html', {
        'bookmarks': bookmarks
    }) 