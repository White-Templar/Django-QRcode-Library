from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from ..models import Borrower, Book, User, Borrowing, Reservation
from .forms import CustomUserCreationForm, BorrowerEditForm, ReservationForm
from main.forms import BorrowingForm
from django.db.models import Q
from django.db.models.functions import TruncMonth
from django.db.models import Count, Value, CharField
from django.db.models.functions import Concat
import json
from django.views.decorators.csrf import csrf_exempt
import csv
from main.models import Borrowing
import matplotlib.pyplot as plt
import io
import base64
import calendar

def register(request):
    """Register a new user."""
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user, backend='main.auth_backend.EmailOrUsernameModelBackend')
            messages.success(request, 'Registration successful!')
            return redirect('home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'main/register.html', {'form': form})

def login_view(request):
    """Login view for regular users."""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None and not user.is_staff:
            login(request, user)
            messages.success(request, f'Welcome back, {user.get_full_name() or user.username}!')
            return redirect('home')
        else:
            messages.error(request, 'Invalid credentials or insufficient permissions.')
    return render(request, 'main/login.html')

@login_required
def logout_view(request):
    """Logout view."""
    logout(request)
    messages.success(request, 'You have been logged out successfully.')
    return redirect('home')

@login_required
def profile(request):
    """User profile view."""
    user = request.user

    # If the user is a superuser or staff, show a simple profile or admin message
    if user.is_superuser or user.is_staff:
        return render(request, 'main/profile.html', {
            'user': user,
            'is_admin': True,
        })

    # For regular users, try to get the Borrower record
    try:
        borrower = Borrower.objects.get(user=user)
        borrowings = Borrowing.objects.filter(borrower=borrower).order_by('-borrow_date')
        return render(request, 'main/profile.html', {
            'user': user,
            'borrower': borrower,
            'borrowings': borrowings,
            'is_admin': False,
        })
    except Borrower.DoesNotExist:
        messages.error(request, 'No borrower record found for your account. Please contact the administrator.')
        return redirect('home')

def staff_login(request):
    """Staff login view."""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None and user.is_staff:
            login(request, user)
            messages.success(request, f'Welcome back, {user.get_full_name() or user.username}!')
            return redirect('staff_dashboard')
        else:
            messages.error(request, 'Invalid credentials or insufficient permissions.')
    return render(request, 'main/staff_login.html')

@login_required
def staff_dashboard(request):
    """Staff dashboard view with library statistics."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')
    
    # Get library statistics
    total_books = Book.objects.count()
    available_books = Book.objects.filter(available_quantity__gt=0).count()
    total_borrowers = User.objects.filter(is_staff=False).count()
    active_borrowers = Borrowing.objects.filter(return_date__isnull=True).values('borrower').distinct().count()
    current_borrowings = Borrowing.objects.filter(return_date__isnull=True).count()
    overdue_borrowings = Borrowing.objects.filter(
        return_date__isnull=True,
        due_date__lt=timezone.now()
    ).count()
    pending_returns = Borrowing.objects.filter(return_date__isnull=True).count()
    today_returns = Borrowing.objects.filter(
        return_date__isnull=True,
        due_date__date=timezone.now().date()
    ).count()

    recent_activities = []
    # Fetch recent borrowings and returns for display
    recent_borrowings = Borrowing.objects.select_related('book', 'borrower__user').order_by('-borrow_date')[:10] # Get latest 10

    for b in recent_borrowings:
        activity_type = 'Borrowed'
        status = 'Active'
        status_color = 'primary'
        if b.is_returned:
            activity_type = 'Returned'
            status = 'Completed'
            status_color = 'success'
        elif b.due_date < timezone.now() and not b.is_returned:
            status = 'Overdue'
            status_color = 'danger'

        recent_activities.append({
            'date': b.borrow_date,
            'type': activity_type,
            'user': b.borrower.user.get_full_name() or b.borrower.user.username,
            'book': b.book.title,
            'status': status,
            'status_color': status_color,
        })
    
    overdue_borrowings_qs = Borrowing.objects.filter(return_date__isnull=True, due_date__lt=timezone.now()).select_related('book', 'borrower__user')
    overdue_notifications = [
        f"{b.borrower.user.get_full_name() or b.borrower.user.username} is overdue for '{b.book.title}' (Due: {b.due_date.strftime('%b %d, %Y')})"
        for b in overdue_borrowings_qs
    ]

    context = {
        'total_books': total_books,
        'available_books': available_books,
        'total_borrowers': total_borrowers,
        'active_borrowers': active_borrowers,
        'current_borrowings': current_borrowings,
        'overdue_borrowings': overdue_borrowings,
        'pending_returns': pending_returns,
        'today_returns': today_returns,
        'recent_activities': recent_activities, # Add recent activities to context
        'overdue_notifications': overdue_notifications,
    }
    
    return render(request, 'main/staff/staff_dashboard.html', context)

@login_required
def analytics(request):
    """Analytics dashboard view with advanced filtering and chart selection."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    # Filters
    selected_year = request.GET.get('year', str(timezone.now().year))
    selected_month = request.GET.get('month', '')  # '' means all months
    selected_user_type = request.GET.get('user_type', '')  # '' means all types
    selected_chart = request.GET.get('chart_type', 'books_by_category')

    # User type choices (example: Student, Teacher, etc.)
    user_type_choices = [
        ('', 'All User Types'),
        ('student', 'Student'),
        ('teacher', 'Teacher'),
        # Add more as needed
    ]

    # Filter borrowings by user type
    borrowings = Borrowing.objects.filter(return_date__isnull=False)
    if selected_user_type:
        borrowings = borrowings.filter(borrower__user_type=selected_user_type)

    # Filter by year and month
    if selected_year:
        borrowings = borrowings.filter(borrow_date__year=selected_year)
    if selected_month:
        borrowings = borrowings.filter(borrow_date__month=selected_month)

    # --- Chart Data Preparation ---
    # Books by Category (count of returned borrowings per category)
    books_by_category = borrowings.values('book__category').annotate(count=Count('book__category')).order_by('-count')
    books_by_category_labels = [dict(Book.CATEGORY_CHOICES).get(item['book__category'], item['book__category']) for item in books_by_category]
    books_by_category_data = [item['count'] for item in books_by_category]

    # Generate pie chart for Books by Category using matplotlib
    fig, ax = plt.subplots(figsize=(6, 4))
    if books_by_category_data:
        ax.pie(books_by_category_data, labels=books_by_category_labels, autopct='%1.1f%%', startangle=90)
        ax.axis('equal')
        buf = io.BytesIO()
        plt.savefig(buf, format='png', bbox_inches='tight')
        buf.seek(0)
        image_png = buf.getvalue()
        buf.close()
        books_by_category_chart = base64.b64encode(image_png).decode('utf-8')
        plt.close(fig)
    else:
        books_by_category_chart = ''

    # Monthly Borrowing Trends (bar chart, always show all months)
    fig2, ax2 = plt.subplots(figsize=(6, 4))
    if borrowings:
        # Get all months for the selected year
        months = [calendar.month_abbr[m] + f' {selected_year}' for m in range(1, 13)]
        month_numbers = list(range(1, 13))
        # Query borrowings grouped by month
        borrowings_monthly = (
            borrowings
            .annotate(month=TruncMonth('borrow_date'))
            .values('month')
            .annotate(count=Count('id'))
            .order_by('month')
        )
        # Map results to a dict: {(month_number): count}
        monthly_counts = {item['month'].month: item['count'] for item in borrowings_monthly if item['month']}
        # Prepare data for all months (fill 0 if missing)
        borrowing_labels = months
        borrowing_data = [monthly_counts.get(m, 0) for m in month_numbers]
        ax2.bar(borrowing_labels, borrowing_data, color='#0d6efd')
        ax2.set_title('Monthly Borrowing Trends')
        ax2.set_xlabel('Month')
        ax2.set_ylabel('Number of Borrowings')
        plt.xticks(rotation=45)
        buf2 = io.BytesIO()
        plt.tight_layout()
        plt.savefig(buf2, format='png', bbox_inches='tight')
        buf2.seek(0)
        image_png2 = buf2.getvalue()
        buf2.close()
        monthly_borrowing_chart = base64.b64encode(image_png2).decode('utf-8')
        plt.close(fig2)
    else:
        monthly_borrowing_chart = ''

    # User Type Distribution (pie chart)
    fig3, ax3 = plt.subplots(figsize=(6, 4))
    if borrowings:
        user_type_dist = borrowings.values('borrower__user_type').annotate(count=Count('id'))
        user_type_labels = [dict(user_type_choices).get(item['borrower__user_type'], item['borrower__user_type']) for item in user_type_dist]
        user_type_data = [item['count'] for item in user_type_dist]
        ax3.pie(user_type_data, labels=user_type_labels, autopct='%1.1f%%', startangle=90)
        ax3.axis('equal')
        buf3 = io.BytesIO()
        plt.savefig(buf3, format='png', bbox_inches='tight')
        buf3.seek(0)
        image_png3 = buf3.getvalue()
        buf3.close()
        user_type_distribution_chart = base64.b64encode(image_png3).decode('utf-8')
        plt.close(fig3)
    else:
        user_type_distribution_chart = ''

    # Top 5 Most Borrowed Books (bar chart)
    fig4, ax4 = plt.subplots(figsize=(6, 4))
    if borrowings:
        top_borrowed_books = borrowings.values('book__title').annotate(borrow_count=Count('book')).order_by('-borrow_count')[:5]
        top_books_labels = [item['book__title'] for item in top_borrowed_books]
        top_books_data = [item['borrow_count'] for item in top_borrowed_books]
        ax4.bar(top_books_labels, top_books_data, color='#ffc107')
        ax4.set_title('Top 5 Most Borrowed Books')
        ax4.set_xlabel('Book Title')
        ax4.set_ylabel('Number of Borrows')
        plt.xticks(rotation=45)
        buf4 = io.BytesIO()
        plt.tight_layout()
        plt.savefig(buf4, format='png', bbox_inches='tight')
        buf4.seek(0)
        image_png4 = buf4.getvalue()
        buf4.close()
        top_borrowed_books_chart = base64.b64encode(image_png4).decode('utf-8')
        plt.close(fig4)
    else:
        top_borrowed_books_chart = ''

    # Returns per Year (bar chart, always show all years)
    fig5, ax5 = plt.subplots(figsize=(6, 4))
    # Get all years present in the database
    all_years_qs = Borrowing.objects.filter(return_date__isnull=False).dates('return_date', 'year')
    all_years = [str(y.year) for y in all_years_qs]
    # Query filtered borrowings grouped by return year
    returns_by_year = (
        borrowings
        .values('return_date__year')
        .annotate(count=Count('id'))
        .order_by('return_date__year')
    )
    # Map results to a dict: {year: count}
    returns_counts = {str(item['return_date__year']): item['count'] for item in returns_by_year}
    # Prepare data for all years (fill 0 if missing)
    returns_by_year_labels = all_years
    returns_by_year_data = [returns_counts.get(y, 0) for y in all_years]
    if all_years:
        ax5.bar(returns_by_year_labels, returns_by_year_data, color='#17a2b8')
        ax5.set_title('Returns per Year')
        ax5.set_xlabel('Year')
        ax5.set_ylabel('Returns')
        plt.xticks(rotation=45)
        buf5 = io.BytesIO()
        plt.tight_layout()
        plt.savefig(buf5, format='png', bbox_inches='tight')
        buf5.seek(0)
        image_png5 = buf5.getvalue()
        buf5.close()
        returns_by_year_chart = base64.b64encode(image_png5).decode('utf-8')
        plt.close(fig5)
    else:
        returns_by_year_chart = ''

    # --- Modern Analytics (summary) ---
    most_active_borrower = borrowings.values('borrower__user__username').annotate(borrow_count=Count('id')).order_by('-borrow_count').first()
    most_active_borrower_name = most_active_borrower['borrower__user__username'] if most_active_borrower else None
    most_active_borrower_count = most_active_borrower['borrow_count'] if most_active_borrower else 0
    
    # --- Most Popular Category and Book ---
    most_popular_category_info = None
    most_popular_book_in_category = None
    if books_by_category:
        most_popular_category = books_by_category[0]['book__category']
        # Find the most borrowed book within that category
        most_popular_book = borrowings.filter(book__category=most_popular_category).values('book__title').annotate(count=Count('id')).order_by('-count').first()
        most_popular_category_info = {
            'label': dict(Book.CATEGORY_CHOICES).get(most_popular_category, most_popular_category),
            'book_title': most_popular_book['book__title'] if most_popular_book else 'N/A'
        }

    total_borrowers = Borrowing.objects.values('borrower').distinct().count()
    total_borrowings = borrowings.count()
    avg_borrowings_per_user = round(total_borrowings / total_borrowers, 2) if total_borrowers > 0 else 0

    # For month filter dropdown
    months_choices = [(str(m), timezone.datetime(2000, m, 1).strftime('%B')) for m in range(1, 13)]

    # --- Table Data Preparation for Template ---
    # Books by Category
    books_by_category_list = []
    for item in Book.objects.values('category').annotate(count=Count('category')).order_by('-count'):
        books_by_category_list.append({
            'category_label': dict(Book.CATEGORY_CHOICES).get(item['category'], item['category']),
            'count': item['count'],
        })
    # Monthly Borrowing Trends
    monthly_borrowing_list = []
    for item in borrowings_monthly:
        month_label = item['month'].strftime('%b %Y') if item['month'] else 'Unknown'
        monthly_borrowing_list.append({'month_label': month_label, 'count': item['count']})
    # Top 5 Most Borrowed Books
    top_borrowed_books_list = []
    for item in top_borrowed_books:
        top_borrowed_books_list.append({'book__title': item['book__title'], 'borrow_count': item['borrow_count']})

    # Debug prints for chart data
    print('books_by_category_labels:', books_by_category_labels)
    print('books_by_category_data:', books_by_category_data)
    print('borrowing_labels:', borrowing_labels)
    print('borrowing_data:', borrowing_data)
    print('top_books_labels:', top_books_labels)
    print('top_books_data:', top_books_data)
    print('user_type_labels:', user_type_labels)
    print('user_type_data:', user_type_data)

    # Borrowings by Year (returns per year)
    returns_by_year = (
        borrowings
        .values('return_date__year')
        .annotate(count=Count('id'))
        .order_by('return_date__year')
    )
    returns_by_year_labels = [str(item['return_date__year']) for item in returns_by_year]
    returns_by_year_data = [item['count'] for item in returns_by_year]

    context = {
        'page_title': 'Library Analytics',
        'selected_year': selected_year,
        'selected_month': selected_month,
        'selected_user_type': selected_user_type,
        'selected_chart': selected_chart,
        'user_type_choices': user_type_choices,
        'months_choices': months_choices,
        'available_years': range(timezone.now().year - 5, timezone.now().year + 1),
        # Modern analytics additions:
        'most_active_borrower_name': most_active_borrower_name,
        'most_active_borrower_count': most_active_borrower_count,
        'most_popular_category_info': most_popular_category_info,
        'avg_borrowings_per_user': avg_borrowings_per_user,
        'total_books': Book.objects.count(),
        'total_borrowers': total_borrowers,
        'current_borrowings': Borrowing.objects.filter(return_date__isnull=True).count(),
        'overdue_borrowings': Borrowing.objects.filter(return_date__isnull=True, due_date__lt=timezone.now()).count(),
        # Python-powered analytics for tables:
        'books_by_category': books_by_category_list,
        'monthly_borrowing': monthly_borrowing_list,
        'top_borrowed_books': top_borrowed_books_list,
        # Chart.js data for all charts:
        'books_by_category_labels': json.dumps(books_by_category_labels),
        'books_by_category_data': json.dumps(books_by_category_data),
        'borrowing_labels': json.dumps(borrowing_labels),
        'borrowing_data': json.dumps(borrowing_data),
        'top_books_labels': json.dumps(top_books_labels),
        'top_books_data': json.dumps(top_books_data),
        'user_type_labels': json.dumps(user_type_labels),
        'user_type_data': json.dumps(user_type_data),
        'returns_by_year_labels': json.dumps(returns_by_year_labels),
        'returns_by_year_data': json.dumps(returns_by_year_data),
        'books_by_category_chart': books_by_category_chart,
        'monthly_borrowing_chart': monthly_borrowing_chart,
        'user_type_distribution_chart': user_type_distribution_chart,
        'top_borrowed_books_chart': top_borrowed_books_chart,
        'returns_by_year_chart': returns_by_year_chart,
    }

    return render(request, 'main/staff/analytics.html', context)

@login_required
def staff_books_management(request):
    """Staff books management view with search and filter functionality."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    books = Book.objects.all().order_by('title')

    query = request.GET.get('q')
    category_filter = request.GET.get('category')
    availability_filter = request.GET.get('availability')

    if query:
        books = books.filter(
            Q(title__icontains=query) |
            Q(author__icontains=query) |
            Q(isbn__icontains=query)
        )

    if category_filter:
        books = books.filter(category=category_filter)

    if availability_filter:
        if availability_filter == 'available':
            books = books.filter(available_quantity__gt=0)
        elif availability_filter == 'unavailable':
            books = books.filter(available_quantity=0)

    context = {
        'page_title': 'Books Management',
        'books': books,
        'categories': Book.CATEGORY_CHOICES,
        'selected_category': category_filter,
        'selected_availability': availability_filter,
        'search_query': query,
    }
    return render(request, 'main/staff/books_management.html', context)

@login_required
def staff_borrowings_management(request):
    """Staff borrowings management view with search and filter functionality."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    # Exclude returned and late return statuses, and items that are returned
    borrowings = Borrowing.objects.filter(
        ~Q(status__in=['Returned', 'Late Return']),
        is_returned=False
    ).select_related('book', 'borrower__user').order_by('-borrow_date')

    query = request.GET.get('q')
    status_filter = request.GET.get('status_filter')
    borrower_type_filter = request.GET.get('borrower_type')
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    if query:
        borrowings = borrowings.filter(
            Q(book__title__icontains=query) |
            Q(book__isbn__icontains=query) |
            Q(borrower__user__first_name__icontains=query) |
            Q(borrower__user__last_name__icontains=query) |
            Q(borrower__id_number__icontains=query)
        )

    if status_filter:
        if status_filter == 'active':
            # Active and not overdue: status is 'Active' and due date is in the future
            borrowings = borrowings.filter(status='Active', due_date__gte=timezone.now().date())
        elif status_filter == 'overdue':
            # Overdue and not returned: status is 'Active' and due date is in the past
            borrowings = borrowings.filter(status='Active', due_date__lt=timezone.now().date())
        elif status_filter == 'pending':
            # Pending status
            borrowings = borrowings.filter(status='Pending')

    if borrower_type_filter:
        borrowings = borrowings.filter(borrower__user_type=borrower_type_filter)

    if start_date:
        borrowings = borrowings.filter(borrow_date__gte=start_date)
    if end_date:
        borrowings = borrowings.filter(borrow_date__lte=end_date)
    
    context = {
        'page_title': 'Borrowings Management',
        'borrowings': borrowings,
        'now': timezone.now(),
        'search_query': query,
        'selected_status': status_filter,
        'borrower_types': Borrower.USER_TYPE_CHOICES,
        'selected_borrower_type': borrower_type_filter,
        'selected_start_date': start_date,
        'selected_end_date': end_date,
    }
    return render(request, 'main/staff/borrowings_management.html', context)

@login_required
def staff_returns_management(request):
    """Staff returns management view with search and filter functionality."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    # Show returned items, late returns, and overdue items that haven't been returned
    returns = Borrowing.objects.filter(
        Q(status__in=['Returned', 'Late Return']) |
        Q(is_returned=True) |
        Q(due_date__lt=timezone.now(), is_returned=False)
    ).select_related('book', 'borrower__user').order_by('-return_date', '-borrow_date')

    query = request.GET.get('q')
    status_filter = request.GET.get('status_filter')
    borrower_type_filter = request.GET.get('borrower_type')
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    if query:
        returns = returns.filter(
            Q(book__title__icontains=query) |
            Q(book__isbn__icontains=query) |
            Q(borrower__user__first_name__icontains=query) |
            Q(borrower__user__last_name__icontains=query) |
            Q(borrower__id_number__icontains=query)
        )

    if status_filter:
        if status_filter == 'returned':
            returns = returns.filter(Q(is_returned=True) | Q(status__in=['Returned', 'Late Return']))
        elif status_filter == 'overdue': # Overdue and not returned
            returns = returns.filter(due_date__lt=timezone.now(), is_returned=False)

    if borrower_type_filter:
        returns = returns.filter(borrower__user_type=borrower_type_filter)

    if start_date:
        returns = returns.filter(borrow_date__gte=start_date)
    if end_date:
        returns = returns.filter(borrow_date__lte=end_date)

    context = {
        'page_title': 'Returns Management',
        'returns': returns,
        'current_time': timezone.now(), # Pass current time for template comparisons
        'search_query': query,
        'selected_status': status_filter,
        'borrower_types': Borrower.USER_TYPE_CHOICES,
        'selected_borrower_type': borrower_type_filter,
        'selected_start_date': start_date,
        'selected_end_date': end_date,
    }
    return render(request, 'main/staff/returns_management.html', context)

@login_required
def register_borrower(request):
    """Staff view for registering new borrowers."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    from .forms import CustomUserCreationForm
    user_type = None
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        user_type = request.POST.get('user_type')
        if form.is_valid():
            form.save()
            messages.success(request, 'New borrower registered successfully!')
            return redirect('borrowers')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = CustomUserCreationForm()
    context = {
        'page_title': 'Register New Borrower',
        'form': form,
        'selected_user_type': user_type,
    }
    return render(request, 'main/staff/register_borrower.html', context)

@login_required
def process_borrowing(request):
    """Staff view for processing new borrowings."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    from main.forms import BorrowingForm
    if request.method == 'POST':
        form = BorrowingForm(request.POST)
        if form.is_valid():
            borrowing = form.save()
            # Decrement book available_quantity if status is Active
            if borrowing.status == 'Active':
                book = borrowing.book
                if book.available_quantity > 0:
                    book.available_quantity -= 1
                    book.save()
            messages.success(request, 'Borrowing processed successfully!')
            return redirect('borrowing')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = BorrowingForm()
    context = {
        'page_title': 'Process New Borrowing',
        'form': form,
    }
    return render(request, 'main/staff/process_borrowing.html', context)

@login_required
def process_return(request, borrowing_id=None):
    """Staff view for processing book returns."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    if borrowing_id:
        # Handle specific return with borrowing_id
        try:
            borrowing = Borrowing.objects.get(id=borrowing_id, is_returned=False)
            borrowing.is_returned = True
            borrowing.return_date = timezone.now()
            borrowing.status = 'Returned'
            borrowing.save()
            
            # Update book availability
            book = borrowing.book
            book.available_quantity += 1
            book.save()
            
            messages.success(request, f'Book "{book.title}" has been returned successfully.')
            return redirect('staff_dashboard')
        except Borrowing.DoesNotExist:
            messages.error(request, 'Borrowing not found or already returned.')
            return redirect('process_return_general')
        except Exception as e:
            messages.error(request, f'Error processing return: {str(e)}')
            return redirect('process_return_general')
    
    # Handle GET request or form submission for general return page
    if request.method == 'POST':
        borrowing_id = request.POST.get('borrowing')
        if borrowing_id:
            return redirect('process_return', borrowing_id=borrowing_id)
    
    active_borrowings = Borrowing.objects.filter(is_returned=False)
    context = {
        'page_title': 'Process Book Return',
        'active_borrowings': active_borrowings
    }
    return render(request, 'main/staff/process_return.html', context)

@login_required
def add_book(request):
    """Staff view for adding new books."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')
    from main.backend.forms import BookForm
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            book = form.save()
            messages.success(request, f'Book "{book.title}" added successfully.')
            return redirect('view_book', book_id=book.id)
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = BookForm()
    context = {
        'page_title': 'Add New Book',
        'form': form,
    }
    return render(request, 'main/staff/add_book.html', context)

@login_required
def staff_borrowers_management(request):
    """Staff borrowers management view with search and filter functionality."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    borrowers = Borrower.objects.select_related('user').all()

    query = request.GET.get('q')
    user_type_filter = request.GET.get('user_type')
    status_filter = request.GET.get('status')
    department_filter = request.GET.get('department')
    course_filter = request.GET.get('course')

    if query:
        borrowers = borrowers.annotate(
            full_name=Concat('user__first_name', Value(' '), 'user__last_name', output_field=CharField()),
            full_name_rev=Concat('user__last_name', Value(' '), 'user__first_name', output_field=CharField())
        ).filter(
            Q(full_name__icontains=query) |
            Q(full_name_rev__icontains=query) |
            Q(id_number__icontains=query) |
            Q(user__email__icontains=query)
        )

    if user_type_filter:
        borrowers = borrowers.filter(user_type=user_type_filter)

    if status_filter:
        if status_filter == 'active_borrowing':
            active_borrower_ids = Borrowing.objects.filter(is_returned=False).values_list('borrower_id', flat=True).distinct()
            borrowers = borrowers.filter(id__in=active_borrower_ids)
    elif status_filter == 'inactive':
        borrowers = borrowers.filter(is_active=False)

    if department_filter:
        borrowers = borrowers.filter(department__icontains=department_filter)
    if course_filter:
        borrowers = borrowers.filter(course__icontains=course_filter)

    # Get all unique departments and courses for the filter dropdowns
    departments = Borrower.objects.exclude(department__isnull=True).exclude(department__exact='').values_list('department', flat=True).distinct()
    courses = Borrower.objects.exclude(course__isnull=True).exclude(course__exact='').values_list('course', flat=True).distinct()

    context = {
        'page_title': 'Borrowers Management',
        'borrowers': borrowers,
        'search_query': query,
        'selected_user_type': user_type_filter,
        'selected_status': status_filter,
        'selected_department': department_filter,
        'selected_course': course_filter,
        'user_types': Borrower.USER_TYPE_CHOICES,
        'departments': departments,
        'courses': courses,
    }
    return render(request, 'main/staff/borrowers_management.html', context)

@login_required
def edit_book(request, book_id):
    """Staff view for editing an existing book."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')
    book = get_object_or_404(Book, id=book_id)
    from main.backend.forms import BookForm
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES, instance=book)
        if form.is_valid():
            form.save()
            messages.success(request, f'Book "{book.title}" updated successfully.')
            return redirect('view_book', book_id=book.id)
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = BookForm(instance=book)
    context = {
        'page_title': 'Edit Book',
        'book_id': book_id,
        'form': form,
        'book': book,
    }
    return render(request, 'main/staff/edit_book.html', context)

@login_required
def delete_book(request, book_id):
    """Staff view for deleting a book."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')
    
    book = get_object_or_404(Book, id=book_id)

    if request.method == 'POST':
        book.delete()
        messages.success(request, f'Book "{book.title}" deleted successfully.')
        return redirect('book')  # Redirect to the book management page

    context = {
        'page_title': 'Delete Book',
        'book_id': book_id,
        'book': book,
    }
    return render(request, 'main/staff/delete_book.html', context)

@login_required
def edit_borrower(request, borrower_id):
    """Staff view for editing borrower details."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    borrower = get_object_or_404(Borrower.objects.select_related('user'), id=borrower_id)

    if request.method == 'POST':
        form = BorrowerEditForm(request.POST, instance=borrower)
        if form.is_valid():
            form.save()
            messages.success(request, f'Borrower {borrower.user.get_full_name() or borrower.user.username} updated successfully.')
            return redirect('borrowers')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = BorrowerEditForm(instance=borrower)

    context = {
        'page_title': 'Edit Borrower',
        'form': form,
        'borrower': borrower,
    }
    return render(request, 'main/staff/edit_borrower.html', context)

@login_required
def delete_borrower(request, borrower_id):
    """Staff view for deleting a borrower."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    borrower = get_object_or_404(Borrower, id=borrower_id)

    if request.method == 'POST':
        try:
            user = borrower.user
            borrower.delete() # Deletes the Borrower instance
            user.delete() # Deletes the associated User instance
            messages.success(request, f'Borrower {user.get_full_name() or user.username} and associated user deleted successfully.')
            return redirect('borrowers')
        except Exception as e:
            messages.error(request, f'Error deleting borrower: {e}')

    context = {
        'page_title': 'Confirm Delete Borrower',
        'borrower': borrower
    }
    return render(request, 'main/staff/delete_borrower.html', context)

@login_required
def edit_borrowing(request, borrowing_id):
    """Staff view for editing a borrowing record."""
    borrowing = get_object_or_404(Borrowing, id=borrowing_id)

    # Calculate days overdue (if any)
    now = timezone.now().date()
    days_overdue = 0
    if borrowing.due_date and not borrowing.is_returned and now > borrowing.due_date.date():
        days_overdue = (now - borrowing.due_date.date()).days + 1
    elif borrowing.due_date and borrowing.is_returned and borrowing.return_date and borrowing.return_date.date() > borrowing.due_date.date():
        days_overdue = (borrowing.return_date.date() - borrowing.due_date.date()).days + 1

    if request.method == 'POST':
        form = BorrowingForm(request.POST, instance=borrowing)
        if form.is_valid():
            updated_borrowing = form.save(commit=False)
            updated_borrowing.status = updated_borrowing.dynamic_status
            updated_borrowing.penalty_amount = updated_borrowing.calculated_penalty
            if form.cleaned_data.get('is_returned') and not borrowing.is_returned:
                book = updated_borrowing.book
                book.available_quantity += 1
                book.save()
            updated_borrowing.save()
            messages.success(request, 'Borrowing record updated successfully.')
            return redirect('view_borrowing', borrowing_id=borrowing.id)
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = BorrowingForm(instance=borrowing)

    context = {
        'page_title': 'Edit Borrowing',
        'form': form,
        'borrowing': borrowing,
        'current_penalty': borrowing.calculated_penalty,
        'days_overdue': days_overdue,
    }
    return render(request, 'main/staff/edit_borrowing.html', context)

@login_required
def delete_borrowing(request, borrowing_id):
    """Staff view for deleting a borrowing record."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    borrowing = get_object_or_404(Borrowing, id=borrowing_id)

    if request.method == 'POST':
        try:
            borrowing.delete()
            messages.success(request, f'Borrowing record {borrowing.id} deleted successfully.')
            return redirect('borrowing')
        except Exception as e:
            messages.error(request, f'Error deleting borrowing record: {e}')

    context = {
        'page_title': 'Confirm Delete Borrowing',
        'borrowing': borrowing
    }
    return render(request, 'main/staff/delete_borrowing.html', context)

@login_required
def view_borrower(request, borrower_id):
    """Staff view for displaying details of a single borrower."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    borrower = get_object_or_404(Borrower.objects.select_related('user'), id=borrower_id)
    
    # Fetch borrowings associated with this borrower
    borrowings = Borrowing.objects.filter(borrower=borrower).select_related('book').order_by('-borrow_date')

    # Calculate statistics for the template
    current_time = timezone.now()
    active_borrowings_count = borrowings.filter(is_returned=False).count()
    overdue_books_count = borrowings.filter(is_returned=False, due_date__lt=current_time).count()

    context = {
        'page_title': 'Borrower Details',
        'borrower': borrower,
        'borrowings': borrowings,
        'active_borrowings_count': active_borrowings_count,
        'overdue_books_count': overdue_books_count,
        'current_time': current_time, # Pass current time for template comparisons
    }
    return render(request, 'main/staff/view_borrower.html', context)

@login_required
def view_book(request, book_id):
    """Staff view for displaying details of a single book."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    book = get_object_or_404(Book, id=book_id)
    
    # Fetch related borrowings for this book
    borrowings = Borrowing.objects.filter(book=book).select_related('borrower__user').order_by('-borrow_date')

    # Calculate statistics for the template
    currently_borrowed_count = borrowings.filter(is_returned=False).count()
    current_time = timezone.now()

    context = {
        'page_title': 'Book Details',
        'book': book,
        'borrowings': borrowings,
        'currently_borrowed_count': currently_borrowed_count,
        'current_time': current_time, # Pass current time for template comparisons
    }
    return render(request, 'main/staff/view_book.html', context)

@login_required
def view_borrowing(request, borrowing_id):
    """Staff view for displaying details of a single borrowing record."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    borrowing = get_object_or_404(Borrowing.objects.select_related('book', 'borrower__user'), id=borrowing_id)
    current_time = timezone.now()

    context = {
        'page_title': 'Borrowing Details',
        'borrowing': borrowing,
        'current_time': current_time,
    }
    return render(request, 'main/staff/view_borrowing.html', context)

@login_required
def staff_reservations_management(request):
    """Staff reservations management view with search and filter functionality."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    reservations = Reservation.objects.select_related('book', 'borrower__user').order_by('-reservation_date')

    query = request.GET.get('q')
    status_filter = request.GET.get('status_filter')
    borrower_type_filter = request.GET.get('borrower_type')
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    if query:
        reservations = reservations.filter(
            Q(book__title__icontains=query) |
            Q(book__isbn__icontains=query) |
            Q(borrower__user__first_name__icontains=query) |
            Q(borrower__user__last_name__icontains=query) |
            Q(borrower__id_number__icontains=query)
        )

    if status_filter:
        current_time = timezone.now()
        if status_filter == 'active':
            reservations = reservations.filter(is_fulfilled=False, is_expired=False, expiry_date__gte=current_time)
        elif status_filter == 'fulfilled':
            reservations = reservations.filter(is_fulfilled=True)
        elif status_filter == 'expired':
            reservations = reservations.filter(is_expired=True)

    if borrower_type_filter:
        reservations = reservations.filter(borrower__user_type=borrower_type_filter)

    if start_date:
        reservations = reservations.filter(reservation_date__gte=start_date)
    if end_date:
        reservations = reservations.filter(reservation_date__lte=end_date)

    context = {
        'page_title': 'Reservations Management',
        'reservations': reservations,
        'current_time': timezone.now(),
        'search_query': query,
        'selected_status': status_filter,
        'borrower_types': Borrower.USER_TYPE_CHOICES,
        'selected_borrower_type': borrower_type_filter,
        'selected_start_date': start_date,
        'selected_end_date': end_date,
    }
    return render(request, 'main/staff/reservations_management.html', context)

@login_required
def view_reservation(request, pk):
    """Staff view to display details of a single reservation."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    try:
        reservation = Reservation.objects.select_related('book', 'borrower__user').get(pk=pk)
    except Reservation.DoesNotExist:
        messages.error(request, 'Reservation not found.')
        return redirect('reservations')

    context = {
        'page_title': 'View Reservation',
        'reservation': reservation,
        'current_time': timezone.now(),
    }
    return render(request, 'main/staff/view_reservation.html', context)

@login_required
def edit_reservation(request, pk):
    """Staff view to edit an existing reservation."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    try:
        reservation = Reservation.objects.get(pk=pk)
    except Reservation.DoesNotExist:
        messages.error(request, 'Reservation not found.')
        return redirect('reservations')

    was_fulfilled = reservation.is_fulfilled

    if request.method == 'POST':
        form = ReservationForm(request.POST, instance=reservation)
        if form.is_valid():
            updated_reservation = form.save(commit=False)
            # If marking as fulfilled and it was not fulfilled before, create borrowing
            if updated_reservation.is_fulfilled and not was_fulfilled:
                from django.utils import timezone
                from main.models import Borrowing
                # Only create if not already an active borrowing for this book and borrower
                already_borrowed = Borrowing.objects.filter(
                    book=updated_reservation.book,
                    borrower=updated_reservation.borrower,
                    is_returned=False
                ).exists()
                if not already_borrowed:
                    # Create a new borrowing record with status 'Active'
                    Borrowing.objects.create(
                        book=updated_reservation.book,
                        borrower=updated_reservation.borrower,
                        borrow_date=timezone.now(),
                        due_date=timezone.now() + timezone.timedelta(days=14),
                        is_returned=False,
                        status='Active'
                    )
                    # Decrease the available quantity of the book
                    updated_reservation.book.available_quantity -= 1
                    updated_reservation.book.save()
            updated_reservation.save()
            messages.success(request, 'Reservation updated successfully.')
            return redirect('view_reservation', pk=reservation.id)
    else:
        form = ReservationForm(instance=reservation)

    context = {
        'page_title': 'Edit Reservation',
        'form': form,
        'reservation': reservation,
    }
    return render(request, 'main/staff/edit_reservation.html', context)

@login_required
def delete_reservation(request, pk):
    """Staff view to delete a reservation."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied. Staff only.')
        return redirect('home')

    try:
        reservation = Reservation.objects.get(pk=pk)
    except Reservation.DoesNotExist:
        messages.error(request, 'Reservation not found.')
        return redirect('reservations')

    if request.method == 'POST':
        reservation.delete()
        messages.success(request, 'Reservation deleted successfully.')
        return redirect('reservations')

    context = {
        'page_title': 'Delete Reservation',
        'reservation': reservation,
    }
    return render(request, 'main/staff/delete_reservation.html', context)

@csrf_exempt
def upload_returns_csv(request):
    if request.method == 'POST' and request.FILES.get('csv_file'):
        csv_file = request.FILES['csv_file']
        
        # Check file extension
        if not csv_file.name.endswith('.csv'):
            messages.error(request, "Error: Please upload a valid CSV file. The file must have a .csv extension.")
            return redirect('return')
        
        # Check file size (limit to 10MB)
        if csv_file.size > 10 * 1024 * 1024:
            messages.error(request, "Error: File size too large. Please upload a CSV file smaller than 10MB.")
            return redirect('return')
        
        try:
            # Try to decode the file
            try:
                decoded_file = csv_file.read().decode('utf-8').splitlines()
            except UnicodeDecodeError:
                messages.error(request, "Error: Unable to read the CSV file. Please ensure the file is encoded in UTF-8 format.")
                return redirect('return')
            
            # Check if file is empty
            if not decoded_file:
                messages.error(request, "Error: The CSV file is empty. Please upload a file with data.")
                return redirect('return')
            
            reader = csv.DictReader(decoded_file)
            
            # Check if required columns exist
            required_columns = ['email', 'book_title']
            missing_columns = [col for col in required_columns if col not in reader.fieldnames]
            if missing_columns:
                messages.error(request, f"Error: Missing required columns in CSV: {', '.join(missing_columns)}. Required columns: {', '.join(required_columns)}")
                return redirect('return')
            
            updated = 0
            errors = []
            row_number = 1  # Start from 1 for user-friendly error messages
            
            for row in reader:
                row_number += 1
                try:
                    # Validate required fields
                    email = row.get('email', '').strip()
                    if not email:
                        errors.append(f"Row {row_number}: Email is required")
                        continue
                    
                    book_title = row.get('book_title', '').strip()
                    if not book_title:
                        errors.append(f"Row {row_number}: Book title is required")
                        continue
                    
                    # Validate email format
                    if '@' not in email or '.' not in email:
                        errors.append(f"Row {row_number}: Invalid email format '{email}'")
                        continue
                    
                    # --- Borrower/User ---
                    borrower = None
                    user = None
                    
                    try:
                        user = User.objects.filter(email=email).first()
                        if not user:
                            # Create user
                            username = email.split('@')[0]
                            # Ensure username is unique
                            base_username = username
                            counter = 1
                            while User.objects.filter(username=username).exists():
                                username = f"{base_username}{counter}"
                                counter += 1
                            
                            user = User.objects.create_user(
                                username=username,
                                email=email,
                                password=row.get('password', 'Password123'),
                                first_name=row.get('first_name', '').strip(),
                                last_name=row.get('last_name', '').strip()
                            )
                    except Exception as e:
                        errors.append(f"Row {row_number}: Error creating user - {str(e)}")
                        continue
                    
                    try:
                        from main.models import Borrower, Book, Borrowing
                        borrower = Borrower.objects.filter(user=user).first()
                        if not borrower:
                            # Validate user_type
                            user_type = row.get('user_type', 'STUDENT').strip().upper()
                            valid_user_types = ['STUDENT', 'TEACHER', 'STAFF']
                            if user_type not in valid_user_types:
                                errors.append(f"Row {row_number}: Invalid user_type '{user_type}'. Valid types: {', '.join(valid_user_types)}")
                                continue
                            
                            borrower = Borrower.objects.create(
                                user=user,
                                id_number=row.get('id_number', '').strip(),
                                phone_number=row.get('phone_number', '').strip(),
                                address=row.get('address', '').strip(),
                                year_level=row.get('year_level', '').strip(),
                                section=row.get('section', '').strip(),
                                course=row.get('course', '').strip(),
                                department=row.get('department', '').strip(),
                                user_type=user_type
                            )
                    except Exception as e:
                        errors.append(f"Row {row_number}: Error creating borrower - {str(e)}")
                        continue
                    
                    # --- Book ---
                    book = None
                    book_id = row.get('book_id')
                    
                    try:
                        if book_id and str(book_id).isdigit():
                            book = Book.objects.filter(id=book_id).first()
                        
                        if not book:
                            # Try by title
                            book = Book.objects.filter(title=book_title).first()
                        
                        if not book:
                            # Create book if it doesn't exist
                            author = row.get('author', '').strip()
                            if not author:
                                errors.append(f"Row {row_number}: Author is required when creating new book")
                                continue
                            
                            # Validate category
                            category = row.get('category', '').strip()
                            if category and category not in dict(Book.CATEGORY_CHOICES):
                                valid_categories = ', '.join([cat[0] for cat in Book.CATEGORY_CHOICES])
                                errors.append(f"Row {row_number}: Invalid category '{category}'. Valid categories: {valid_categories}")
                                continue
                            
                            # Validate quantity
                            quantity = row.get('available_quantity', 1)
                            try:
                                quantity = int(quantity) if quantity else 1
                                if quantity < 0:
                                    errors.append(f"Row {row_number}: Quantity cannot be negative")
                                    continue
                            except ValueError:
                                errors.append(f"Row {row_number}: Invalid quantity value '{quantity}'. Must be a number.")
                                continue
                            
                            book = Book.objects.create(
                                title=book_title,
                                author=author,
                                isbn=row.get('isbn', '').strip(),
                                category=category or 'fiction',
                                description=row.get('description', '').strip(),
                                quantity=quantity,
                                available_quantity=quantity,
                                cover_image_url=row.get('cover_image_url', '').strip()
                            )
                    except Exception as e:
                        errors.append(f"Row {row_number}: Error with book - {str(e)}")
                        continue
                    
                    # --- Borrowing ---
                    borrowing_id = row.get('borrowing_id')
                    
                    try:
                        if borrowing_id and str(borrowing_id).isdigit():
                            try:
                                borrowing = Borrowing.objects.get(id=borrowing_id)
                                # Update existing borrowing
                                borrowing.return_date = row.get('return_date') or None
                                borrowing.borrow_date = row.get('borrow_date') or None
                                borrowing.due_date = row.get('due_date') or None
                                
                                if borrowing.return_date:
                                    borrowing.status = "Returned"
                                elif borrowing.borrow_date and borrowing.due_date:
                                    borrowing.status = "Active"
                                else:
                                    borrowing.status = "Pending"
                                
                                borrowing.is_returned = bool(borrowing.return_date)
                                
                                # Validate penalty amount
                                penalty_amount = row.get('penalty_amount', 0)
                                try:
                                    penalty_amount = float(penalty_amount) if penalty_amount else 0
                                    if penalty_amount < 0:
                                        errors.append(f"Row {row_number}: Penalty amount cannot be negative")
                                        continue
                                    borrowing.penalty_amount = penalty_amount
                                except ValueError:
                                    errors.append(f"Row {row_number}: Invalid penalty amount '{penalty_amount}'. Must be a number.")
                                    continue
                                
                                borrowing.save()
                                updated += 1
                                continue  # Go to next row after update
                            except Borrowing.DoesNotExist:
                                pass  # Fall through to create new
                        
                        # Create new borrowing
                        borrow_date = row.get('borrow_date') or None
                        due_date = row.get('due_date') or None
                        return_date = row.get('return_date') or None
                        
                        # Validate dates if provided
                        if borrow_date:
                            try:
                                from datetime import datetime
                                datetime.strptime(borrow_date, '%Y-%m-%d')
                            except ValueError:
                                errors.append(f"Row {row_number}: Invalid borrow_date format '{borrow_date}'. Use YYYY-MM-DD format.")
                                continue
                        
                        if due_date:
                            try:
                                from datetime import datetime
                                datetime.strptime(due_date, '%Y-%m-%d')
                            except ValueError:
                                errors.append(f"Row {row_number}: Invalid due_date format '{due_date}'. Use YYYY-MM-DD format.")
                                continue
                        
                        if return_date:
                            try:
                                from datetime import datetime
                                datetime.strptime(return_date, '%Y-%m-%d')
                            except ValueError:
                                errors.append(f"Row {row_number}: Invalid return_date format '{return_date}'. Use YYYY-MM-DD format.")
                                continue
                        
                        if return_date:
                            status = "Returned"
                        elif borrow_date and due_date:
                            status = "Active"
                        else:
                            status = "Pending"
                        
                        # Validate penalty amount
                        penalty_amount = row.get('penalty_amount', 0)
                        try:
                            penalty_amount = float(penalty_amount) if penalty_amount else 0
                            if penalty_amount < 0:
                                errors.append(f"Row {row_number}: Penalty amount cannot be negative")
                                continue
                        except ValueError:
                            errors.append(f"Row {row_number}: Invalid penalty amount '{penalty_amount}'. Must be a number.")
                            continue
                        
                        new_borrowing = Borrowing.objects.create(
                            book=book,
                            borrower=borrower,
                            borrow_date=borrow_date,
                            due_date=due_date,
                            return_date=return_date,
                            is_returned=bool(return_date),
                            penalty_amount=penalty_amount,
                            status=status
                        )
                        updated += 1
                        
                    except Exception as e:
                        errors.append(f"Row {row_number}: Error creating/updating borrowing - {str(e)}")
                        continue
                        
                except Exception as e:
                    errors.append(f"Row {row_number}: Unexpected error - {str(e)}")
                    continue
            
            # Show results
            if updated > 0:
                messages.success(request, f"Successfully processed {updated} returns.")
            
            if errors:
                error_message = f"Upload completed with {len(errors)} errors:\n" + "\n".join(errors[:10])  # Show first 10 errors
                if len(errors) > 10:
                    error_message += f"\n... and {len(errors) - 10} more errors"
                messages.error(request, error_message)
            
            if updated == 0 and errors:
                messages.error(request, "No returns were processed due to errors. Please check the CSV file and try again.")
                
        except csv.Error as e:
            messages.error(request, f"Error reading CSV file: {str(e)}. Please check the file format.")
        except Exception as e:
            messages.error(request, f"Unexpected error during upload: {str(e)}. Please try again.")
    else:
        messages.error(request, "Error: Please upload a valid CSV file.")
    return redirect('return')

def home(request):
    notifications = []
    if request.user.is_authenticated:
        try:
            borrower = Borrower.objects.get(user=request.user)
            overdue_borrowings = Borrowing.objects.filter(borrower=borrower, return_date__isnull=True, due_date__lt=timezone.now()).select_related('book')
            for b in overdue_borrowings:
                notifications.append(f"You are overdue for '{b.book.title}' (Due: {b.due_date.strftime('%b %d, %Y')})")
        except Borrower.DoesNotExist:
            pass
    # ... existing code ...
    context = {
        # ... existing context ...
        'notifications': notifications,
        # ...
    }
    return render(request, 'main/home.html', context) 