from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from datetime import timedelta, datetime
from django.utils.timezone import now as django_now, make_aware # Explicitly import now and make_aware
from ..models import Book, Borrower, Borrowing, Reservation, Bookmark
from django.views.decorators.csrf import csrf_exempt
import csv

def book_list(request):
    """View for listing all books with search and filter functionality"""
    books = Book.objects.all()
    query = request.GET.get('q')
    category = request.GET.get('category')
    
    if query:
        books = books.filter(
            Q(title__icontains=query) |
            Q(author__icontains=query) |
            Q(isbn__icontains=query)
        )
    
    if category:
        books = books.filter(category=category)
    
    # Pass the CATEGORY_CHOICES tuple which has the correct format
    categories = Book.CATEGORY_CHOICES
    
    context = {
        'books': books,
        'categories': categories,
        'selected_category': category,
        'search_query': query,
    }
    
    return render(request, 'main/book_list.html', context)

def book_detail(request, book_id):
    """View for displaying book details and handling borrow/reserve actions"""
    book = get_object_or_404(Book, id=book_id)
    
    # Need to implement is_available, has_active_borrowing, and has_active_reservation methods in the models
    is_available = book.available_quantity > 0
    can_borrow = False
    can_reserve = False
    is_bookmarked = False
    has_active_borrowing = False
    
    if request.user.is_authenticated:
        try:
            borrower = Borrower.objects.get(user=request.user)
            # Check for active borrowing (not returned)
            has_active_borrowing = Borrowing.objects.filter(
                book=book, 
                borrower=borrower, 
                is_returned=False,
                return_date__isnull=True
            ).exists()
            
            # Check if borrower has ANY active borrowings
            has_any_active_borrowing = Borrowing.objects.filter(
                borrower=borrower, 
                is_returned=False,
                return_date__isnull=True
            ).exists()

            has_reserved = Reservation.objects.filter(
                book=book, 
                borrower=borrower, 
                is_fulfilled=False, 
                is_expired=False
            ).exists()
            
            # Can borrow if book is available and not currently borrowed by this user, and user has no other active borrowings
            can_borrow = is_available and not has_active_borrowing and not has_any_active_borrowing
            # Can reserve if book is available, not currently borrowed by this user, not already reserved by this user, and user has no other active borrowings
            can_reserve = is_available and not has_active_borrowing and not has_reserved and not has_any_active_borrowing
            
            # Check if book is bookmarked
            is_bookmarked = Bookmark.objects.filter(user=request.user, book=book).exists()
        except Borrower.DoesNotExist:
            # Handle cases where a User exists but no corresponding Borrower profile
            pass # Or redirect to profile creation

    return render(request, 'main/book_detail.html', {
        'book': book,
        'is_available': is_available,
        'can_borrow': can_borrow,
        'can_reserve': can_reserve,
        'is_bookmarked': is_bookmarked,
        'has_active_borrowing': has_active_borrowing,
        'today': django_now().date(), # Use django_now()
    })

@login_required
def borrow_book(request, book_id):
    """View for handling book borrowing"""
    book = get_object_or_404(Book, id=book_id)
    
    try:
        borrower = Borrower.objects.get(user=request.user)
    except Borrower.DoesNotExist:
        messages.error(request, 'Borrower profile not found.')
        return redirect('profile')

    if book.available_quantity <= 0:
        messages.error(request, 'This book is not available for borrowing.')
        return redirect('book_detail', book_id=book.id)
    
    # Check if user has an active borrowing of this book
    active_borrowing = Borrowing.objects.filter(
        book=book, 
        borrower=borrower, 
        is_returned=False,
        return_date__isnull=True
    ).exists()
    
    if active_borrowing:
        messages.error(request, 'You have already borrowed this book and haven\'t returned it yet.')
        return redirect('book_detail', book_id=book.id)
    
    # Create borrowing record with Pending status
    borrowing = Borrowing.objects.create(
        book=book,
        borrower=borrower,
        borrow_date=None,  # Will be set when staff confirms
        due_date=django_now() + timedelta(days=14),  # 2 weeks borrowing period
        is_returned=False,
        return_date=None,
        status='Pending'  # Set initial status to Pending
    )
    
    # Don't decrease available quantity until staff confirms
    # book.available_quantity -= 1
    # book.save()

    messages.success(request, f'Borrow request for {book.title} has been submitted. Please present the QR code to staff for confirmation.')
    return redirect('show_borrowing_qrcode', borrowing_id=borrowing.id)

@login_required
def return_book(request, borrowing_id):
    """View for handling book returns"""
    borrowing = get_object_or_404(Borrowing, id=borrowing_id)
    
    if borrowing.borrower.user != request.user:
        messages.error(request, 'You are not authorized to return this book.')
        return redirect('borrowing_history')
    
    if borrowing.return_date:
        messages.error(request, 'This book has already been returned.')
        return redirect('borrowing_history')
    
    borrowing.return_date = django_now() # Use django_now()
    borrowing.is_returned = True  # Set is_returned flag to True
    # Calculate penalty before saving
    if borrowing.return_date > borrowing.due_date:
        days_overdue = (borrowing.return_date - borrowing.due_date).days
        borrowing.penalty_amount = days_overdue * 50  # ₱50 per day
    borrowing.save()
    
    # Increase available quantity
    book = borrowing.book
    book.available_quantity += 1
    book.save()

    messages.success(request, f'Successfully returned {borrowing.book.title}.')
    if borrowing.penalty_amount > 0:
         messages.warning(request, f'Overdue penalty: ₱{borrowing.penalty_amount:.2f}.')

    return redirect('borrowing_history')

@login_required
def reserve_book(request, book_id):
    """View for handling book reservations"""
    book = get_object_or_404(Book, id=book_id)
    
    try:
        borrower = Borrower.objects.get(user=request.user)
    except Borrower.DoesNotExist:
        messages.error(request, 'Borrower profile not found.')
        return redirect('profile')

    if book.available_quantity == 0:
        messages.error(request, 'This book is not available for borrowing. You can only reserve books that are currently borrowed.')
        return redirect('book_detail', book_id=book.id)
    
    if Reservation.objects.filter(book=book, borrower=borrower, is_fulfilled=False, is_expired=False).exists():
        messages.error(request, 'You have already reserved this book.')
        return redirect('book_detail', book_id=book.id)
    
    # Check if the user has any active borrowings
    has_any_active_borrowing = Borrowing.objects.filter(
        borrower=borrower, 
        is_returned=False,
        return_date__isnull=True
    ).exists()

    if has_any_active_borrowing:
        messages.error(request, 'You cannot reserve a book while you have an unreturned borrowed book.')
        return redirect('book_detail', book_id=book.id)

    pickup_date_str = request.POST.get('pickup_date')
    pickup_datetime = None
    if pickup_date_str:
        try:
            # Assuming the date format from the input is YYYY-MM-DD
            naive_pickup_datetime = datetime.strptime(pickup_date_str, '%Y-%m-%d')
            pickup_datetime = make_aware(naive_pickup_datetime) # Use make_aware
            # Ensure pickup date is not in the past
            if pickup_datetime < django_now() - timedelta(days=1): # Allow today's date if selected today
                messages.error(request, 'Pickup date cannot be in the past.')
                return redirect('book_detail', book_id=book.id)
        except ValueError:
            messages.error(request, 'Invalid pickup date format.')
            return redirect('book_detail', book_id=book.id)

    # Create reservation
    reservation = Reservation.objects.create(
        book=book,
        borrower=borrower,
        reservation_date=django_now(), # Use django_now()
        pickup_date=pickup_datetime # Pass the chosen pickup date
    )
    
    messages.success(request, f'Successfully reserved {book.title}. Your reservation expires on {reservation.expiry_date.strftime("%Y-%m-%d %H:%M")}.')
    return redirect('book_detail', book_id=book.id)

@login_required
def cancel_reservation(request, reservation_id):
    """View for handling reservation cancellations"""
    reservation = get_object_or_404(Reservation, id=reservation_id)
    
    if reservation.borrower.user != request.user:
        messages.error(request, 'You are not authorized to cancel this reservation.')
        return redirect('borrowing_history')
    
    if reservation.is_fulfilled or reservation.is_expired:
        messages.error(request, 'This reservation cannot be cancelled.')
        return redirect('borrowing_history')
    
    reservation.is_expired = True # Mark as expired instead of deleting
    reservation.save()
    messages.success(request, f'Successfully cancelled reservation for {reservation.book.title}.')
    return redirect('borrowing_history')

@login_required
def borrowing_history(request):
    """View for displaying user's borrowing and reservation history"""
    try:
        borrower = Borrower.objects.get(user=request.user)
    except Borrower.DoesNotExist:
        messages.error(request, 'Borrower profile not found.')
        # Render an empty history page or redirect to profile creation
        return render(request, 'main/borrowing_history.html', {
            'active_borrowings': [],
            'past_borrowings': [],
            'active_reservations': [],
            'past_reservations': []
        })

    # Get active borrowings and calculate penalties for overdue books
    active_borrowings = []
    for borrowing in borrower.borrowing_set.filter(return_date__isnull=True).order_by('-borrow_date'):
        is_overdue = (
            (borrowing.due_date < django_now() and not borrowing.is_returned)
            or (borrowing.borrow_date and borrowing.borrow_date > borrowing.due_date)
        )
        if is_overdue:
            if borrowing.borrow_date and borrowing.borrow_date > borrowing.due_date:
                overdue_days = (borrowing.borrow_date - borrowing.due_date).days
            else:
                overdue_days = (django_now() - borrowing.due_date).days
            penalty_amount = overdue_days * 50
            Borrowing.objects.filter(id=borrowing.id).update(
                penalty_amount=penalty_amount,
                status='Overdue'
            )
            borrowing.penalty_amount = penalty_amount
            borrowing.status = 'Overdue'
        active_borrowings.append(borrowing)
    
    # Get past borrowings with their penalties
    past_borrowings = []
    for borrowing in borrower.borrowing_set.filter(return_date__isnull=False).order_by('-return_date'):
        if borrowing.return_date > borrowing.due_date:
            # Calculate penalty for late returns (₱50 per day)
            overdue_days = (borrowing.return_date - borrowing.due_date).days
            penalty_amount = overdue_days * 50
            # Update the borrowing record in the database
            Borrowing.objects.filter(id=borrowing.id).update(
                penalty_amount=penalty_amount,
                status='Late Return'
            )
            # Update the instance for the current context
            borrowing.penalty_amount = penalty_amount
            borrowing.status = 'Late Return'
        past_borrowings.append(borrowing)
    
    active_reservations = borrower.reservation_set.filter(is_fulfilled=False, is_expired=False).order_by('-reservation_date')
    past_reservations = borrower.reservation_set.filter(Q(is_fulfilled=True) | Q(is_expired=True)).order_by('-reservation_date')
    
    return render(request, 'main/borrowing_history.html', {
        'active_borrowings': active_borrowings,
        'past_borrowings': past_borrowings,
        'active_reservations': active_reservations,
        'past_reservations': past_reservations,
        'now': django_now(), # Use django_now() for template comparison
    })

@login_required
@csrf_exempt
def upload_books_csv(request):
    if request.method == 'POST' and request.FILES.get('csv_file'):
        csv_file = request.FILES['csv_file']
        
        # Check file extension
        if not csv_file.name.endswith('.csv'):
            messages.error(request, "Error: Please upload a valid CSV file. The file must have a .csv extension.")
            return redirect('book')
        
        # Check file size (limit to 10MB)
        if csv_file.size > 10 * 1024 * 1024:
            messages.error(request, "Error: File size too large. Please upload a CSV file smaller than 10MB.")
            return redirect('book')
        
        try:
            # Try to decode the file
            try:
                decoded_file = csv_file.read().decode('utf-8').splitlines()
            except UnicodeDecodeError:
                messages.error(request, "Error: Unable to read the CSV file. Please ensure the file is encoded in UTF-8 format.")
                return redirect('book')
            
            # Check if file is empty
            if not decoded_file:
                messages.error(request, "Error: The CSV file is empty. Please upload a file with data.")
                return redirect('book')
            
            reader = csv.DictReader(decoded_file)
            
            # Check if required columns exist
            required_columns = ['title', 'author']
            missing_columns = [col for col in required_columns if col not in reader.fieldnames]
            if missing_columns:
                messages.error(request, f"Error: Missing required columns in CSV: {', '.join(missing_columns)}. Required columns: {', '.join(required_columns)}")
                return redirect('book')
            
            added = 0
            errors = []
            row_number = 1  # Start from 1 for user-friendly error messages
            
            for row in reader:
                row_number += 1
                try:
                    # Validate required fields
                    if not row.get('title', '').strip():
                        errors.append(f"Row {row_number}: Title is required")
                        continue
                    
                    if not row.get('author', '').strip():
                        errors.append(f"Row {row_number}: Author is required")
                        continue
                    
                    # Validate category if provided
                    category = row.get('category', '').strip()
                    if category and category not in dict(Book.CATEGORY_CHOICES):
                        valid_categories = ', '.join([cat[0] for cat in Book.CATEGORY_CHOICES])
                        errors.append(f"Row {row_number}: Invalid category '{category}'. Valid categories: {valid_categories}")
                        continue
                    
                    # Validate quantity if provided
                    quantity = row.get('available_quantity', 1)
                    try:
                        quantity = int(quantity) if quantity else 1
                        if quantity < 0:
                            errors.append(f"Row {row_number}: Quantity cannot be negative")
                            continue
                    except ValueError:
                        errors.append(f"Row {row_number}: Invalid quantity value '{quantity}'. Must be a number.")
                        continue
                    
                    # Check for duplicate ISBN if provided
                    isbn = row.get('isbn', '').strip()
                    if isbn and Book.objects.filter(isbn=isbn).exists():
                        errors.append(f"Row {row_number}: ISBN '{isbn}' already exists in the database")
                        continue
                    
                    # Create the book
                    Book.objects.create(
                        title=row.get('title', '').strip(),
                        author=row.get('author', '').strip(),
                        isbn=isbn,
                        category=category or 'fiction',  # Default to fiction if not provided
                        description=row.get('description', '').strip(),
                        quantity=quantity,
                        available_quantity=quantity,
                        cover_image_url=row.get('cover_image_url', '').strip()
                    )
                    added += 1
                    
                except Exception as e:
                    errors.append(f"Row {row_number}: Unexpected error - {str(e)}")
                    continue
            
            # Show results
            if added > 0:
                messages.success(request, f"Successfully uploaded {added} books.")
            
            if errors:
                error_message = f"Upload completed with {len(errors)} errors:\n" + "\n".join(errors[:10])  # Show first 10 errors
                if len(errors) > 10:
                    error_message += f"\n... and {len(errors) - 10} more errors"
                messages.error(request, error_message)
            
            if added == 0 and errors:
                messages.error(request, "No books were uploaded due to errors. Please check the CSV file and try again.")
                
        except csv.Error as e:
            messages.error(request, f"Error reading CSV file: {str(e)}. Please check the file format.")
        except Exception as e:
            messages.error(request, f"Unexpected error during upload: {str(e)}. Please try again.")
    else:
        messages.error(request, "Error: Please upload a valid CSV file.")
    return redirect('book') 