from django.contrib import admin
from .models import Book, Borrower, Borrowing, Reservation

# Register your models here.
admin.site.register(Book)
admin.site.register(Borrower)
admin.site.register(Borrowing)
admin.site.register(Reservation)
