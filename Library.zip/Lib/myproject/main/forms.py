from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Book, Borrower, Borrowing, Reservation
from django.utils.timezone import now
import requests
from django.core.files.base import ContentFile
from urllib.parse import urlparse

class CustomUserCreationForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        fields = UserCreationForm.Meta.fields + ("email", "first_name", "last_name")

class BookForm(forms.ModelForm):
    cover_image_url = forms.CharField(
        label='Cover Image URL',
        required=False,
        widget=forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'Paste image URL here'})
    )

    class Meta:
        model = Book
        fields = '__all__'

    def save(self, commit=True):
        instance = super().save(commit=False)
        cover_image_url = self.cleaned_data.get('cover_image_url')
        if cover_image_url:
            instance.cover_image_url = cover_image_url
            if not self.cleaned_data.get('cover_image'):
                instance.cover_image = None  # Ensure file field is empty if only using URL
        if commit:
            instance.save()
        return instance

class BorrowerForm(forms.ModelForm):
    class Meta:
        model = Borrower
        fields = '__all__'

class BorrowingForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Exclude 'Overdue' from status choices as it's a calculated state
        self.fields['status'].choices = [
            (key, value) for key, value in self.fields['status'].choices if key != 'Overdue'
        ]

    class Meta:
        model = Borrowing
        exclude = ['is_returned']
        widgets = {
            'borrow_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'due_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'return_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
        }

    def save(self, commit=True):
        instance = super().save(commit=False)
        if instance.status == 'Active' and not instance.borrow_date:
            instance.borrow_date = now()
        if instance.status == 'Returned':
            if not instance.return_date:
                instance.return_date = now()
            instance.is_returned = True
        else:
            instance.is_returned = False
        if commit:
            instance.save()
        return instance

class ReturnForm(forms.Form): # This might need to be a ModelForm depending on your return logic
    borrowing_id = forms.IntegerField()

class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = '__all__' 