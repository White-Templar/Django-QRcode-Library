from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.utils import timezone
from datetime import timedelta
from django.db import transaction
from .models import Book, Borrower, Borrowing, Reservation
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.db.models import Q, Count
from django.http import JsonResponse, Http404
from .forms import CustomUserCreationForm, BookForm, BorrowerForm, BorrowingForm, ReturnForm, ReservationForm
from .models import Bookmark
import qrcode
import base64
from io import BytesIO
import json
from django.views.decorators.csrf import csrf_exempt
import csv

# Helper function to check if user is staff
def is_staff(user):
    return user.is_authenticated and user.is_staff

@login_required
@user_passes_test(is_staff)
def staff_dashboard(request):
    # Get statistics for the dashboard
    total_books = Book.objects.count()
    available_books = Book.objects.filter(available_quantity__gt=0).count()
    
    total_borrowers = Borrower.objects.count()
    active_borrowers = Borrower.objects.filter(
        borrowing__is_returned=False,
        borrowing__return_date__isnull=True
    ).distinct().count()
    
    current_borrowings = Borrowing.objects.filter(
        is_returned=False,
        return_date__isnull=True
    ).count()
    
    overdue_borrowings = Borrowing.objects.filter(
        is_returned=False,
        return_date__isnull=True,
        due_date__lt=timezone.now()
    ).count()
    
    pending_reservations = Reservation.objects.filter(
        is_fulfilled=False,
        is_expired=False
    ).count()
    
    today_reservations = Reservation.objects.filter(
        reservation_date__date=timezone.now().date()
    ).count()
    
    # Get recent activities
    recent_activities = []
    
    # Add recent borrowings
    recent_borrowings = Borrowing.objects.select_related('book', 'borrower').order_by('-borrow_date')[:5]
    for borrowing in recent_borrowings:
        recent_activities.append({
            'date': borrowing.borrow_date,
            'type': 'Borrowing',
            'user': borrowing.borrower.user.get_full_name() or borrowing.borrower.user.username,
            'book': borrowing.book.title,
            'status': 'Returned' if borrowing.is_returned else 'Active',
            'status_color': 'success' if borrowing.is_returned else 'primary'
        })
    
    # Add recent returns
    recent_returns = Borrowing.objects.select_related('book', 'borrower').filter(
        is_returned=True
    ).order_by('-return_date')[:5]
    for return_item in recent_returns:
        recent_activities.append({
            'date': return_item.return_date,
            'type': 'Return',
            'user': return_item.borrower.user.get_full_name() or return_item.borrower.user.username,
            'book': return_item.book.title,
            'status': 'Completed',
            'status_color': 'success'
        })
    
    # Sort activities by date
    recent_activities.sort(key=lambda x: x['date'], reverse=True)
    recent_activities = recent_activities[:10]  # Get only the 10 most recent activities
    
    context = {
        'total_books': total_books,
        'available_books': available_books,
        'total_borrowers': total_borrowers,
        'active_borrowers': active_borrowers,
        'current_borrowings': current_borrowings,
        'overdue_borrowings': overdue_borrowings,
        'pending_reservations': pending_reservations,
        'today_reservations': today_reservations,
        'recent_activities': recent_activities,
    }
    
    return render(request, 'main/staff_dashboard.html', context)

def home(request):
    """View for the home page"""
    # Get statistics for the dashboard
    total_books = Book.objects.count()
    total_borrowers = Borrower.objects.count()
    available_books = Book.objects.filter(available_quantity__gt=0).count()
    notifications = []

    if request.user.is_authenticated and hasattr(request.user, 'borrower'):
        now = timezone.now()
    
        # Overdue books notification
        overdue_borrowings = Borrowing.objects.filter(
            borrower=request.user.borrower,
            is_returned=False,
            due_date__lt=now
        )
        if overdue_borrowings.exists():
            notifications.append(f"You have {overdue_borrowings.count()} overdue book(s). Please return them as soon as possible to avoid further penalties.")

        # Due soon notification
        soon_due = Borrowing.objects.filter(
            borrower=request.user.borrower,
            is_returned=False,
            due_date__gte=now,
            due_date__lte=now + timedelta(days=3)
        )
        if soon_due.exists():
            notifications.append(f"You have {soon_due.count()} book(s) due within 3 days. Please return them on time.")

    return render(request, 'main/home.html', {
        'total_books': total_books,
        'total_borrowers': total_borrowers,
        'available_books': available_books,
        'notifications': notifications,
    })

def login_view(request):
    if request.method == 'POST':
        username_or_email = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(request, username=username_or_email, password=password)
        
        if user is not None:
            login(request, user)
            if user.is_staff:
                return redirect('staff_dashboard')
            return redirect('home')
        else:
            messages.error(request, 'Invalid username/email or password.')
    
    return render(request, 'main/login.html')

def staff_login_view(request):
    if request.method == 'POST':
        username_or_email = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(request, username=username_or_email, password=password)
        
        if user is not None and user.is_staff:
            login(request, user)
            return redirect('staff_dashboard')
        else:
            messages.error(request, 'Invalid staff credentials or insufficient permissions.')
    
    return render(request, 'main/staff_login.html')

@login_required
@user_passes_test(is_staff)
def add_book(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        author = request.POST.get('author')
        isbn = request.POST.get('isbn')
        category = request.POST.get('category')
        description = request.POST.get('description')
        quantity = request.POST.get('quantity', 1)
        
        try:
            book = Book.objects.create(
                title=title,
                author=author,
                isbn=isbn,
                category=category,
                description=description,
                quantity=quantity,
                available_quantity=quantity
            )
            messages.success(request, f'Book "{title}" has been added successfully.')
            return redirect('staff_dashboard')
        except Exception as e:
            messages.error(request, f'Error adding book: {str(e)}')
    
    categories = Book.CATEGORY_CHOICES
    return render(request, 'main/staff/add_book.html', {'categories': categories})

@login_required
@user_passes_test(is_staff)
def register_borrower(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        
        try:
            # Create user
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password,
                first_name=first_name,
                last_name=last_name
            )
            
            # Create borrower profile
            Borrower.objects.create(user=user)
            
            messages.success(request, f'Borrower {first_name} {last_name} has been registered successfully.')
            return redirect('staff_dashboard')
        except Exception as e:
            messages.error(request, f'Error registering borrower: {str(e)}')
    
    return render(request, 'main/staff/register_borrower.html')

@login_required
@user_passes_test(is_staff)
def process_borrowing(request):
    if request.method == 'POST':
        book_id = request.POST.get('book')
        borrower_id = request.POST.get('borrower')
        due_date = request.POST.get('due_date')
        
        try:
            book = Book.objects.get(id=book_id)
            borrower = Borrower.objects.get(id=borrower_id)
            
            if book.available_quantity <= 0:
                messages.error(request, 'This book is not available for borrowing.')
                return redirect('process_borrowing')
            
            # Create borrowing with status 'Active' and set borrow_date
            borrowing = Borrowing.objects.create(
                book=book,
                borrower=borrower,
                due_date=due_date,
                status='Active',
                borrow_date=timezone.now(),
                is_returned=False
            )
            
            book.available_quantity -= 1
            book.save()
            
            messages.success(request, f'Book "{book.title}" has been borrowed successfully.')
            return redirect('staff_dashboard')
        except Exception as e:
            messages.error(request, f'Error processing borrowing: {str(e)}')
    
    books = Book.objects.filter(available_quantity__gt=0)
    borrowers = Borrower.objects.all()
    return render(request, 'main/staff/process_borrowing.html', {
        'books': books,
        'borrowers': borrowers
    })

@login_required
@user_passes_test(is_staff)
def process_return(request, borrowing_id=None):
    if borrowing_id:
        # Handle specific return with borrowing_id (from URL)
        try:
            borrowing = Borrowing.objects.get(id=borrowing_id, is_returned=False)
            borrowing.is_returned = True
            borrowing.return_date = timezone.now()
            borrowing.status = 'Returned'  # Update status to Returned
            borrowing.save()
            
            # Update book availability
            book = borrowing.book
            book.available_quantity += 1
            book.save()
            
            messages.success(request, f'Book "{book.title}" has been returned successfully.')
            return redirect('staff_dashboard')
        except Exception as e:
            messages.error(request, f'Error processing return: {str(e)}')
            return redirect('process_return_general')
    
    # Handle GET request or form submission for general return page
    if request.method == 'POST':
        borrowing_id = request.POST.get('borrowing')
        if borrowing_id:
            return redirect('process_return', borrowing_id=borrowing_id)
    
    active_borrowings = Borrowing.objects.filter(is_returned=False)
    return render(request, 'main/staff/process_return.html', {
        'active_borrowings': active_borrowings
    })

@login_required
def show_borrowing_qrcode(request, borrowing_id):
    try:
        borrowing = Borrowing.objects.select_related('book', 'borrower').get(id=borrowing_id)
        
        # Check if user is authorized to view this QR code
        if not request.user.is_staff and borrowing.borrower.user != request.user:
            messages.error(request, 'You are not authorized to view this QR code.')
            return redirect('borrowing_history')
    
        # Check if book is already returned
        if borrowing.is_returned:
            messages.warning(request, 'This book has already been returned.')
            return redirect('borrowing_history')
        
        # Generate QR code data
        qr_data = {
            'borrowing_id': borrowing.id,
            'book_title': borrowing.book.title,
            'borrower_id': borrowing.borrower.id
        }
        
        # Create QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(json.dumps(qr_data))
        qr.make(fit=True)

        # Create QR code image
        img = qr.make_image(fill_color="black", back_color="white")
    
        # Convert image to base64 for embedding in HTML
        buffered = BytesIO()
        img.save(buffered, format="PNG")
        qr_code_image = base64.b64encode(buffered.getvalue()).decode()
        
        # Format dates for display
        borrow_date = borrowing.borrow_date.strftime("%B %d, %Y %H:%M") if borrowing.borrow_date else "Not yet borrowed"
        due_date = borrowing.due_date.strftime("%B %d, %Y %H:%M")
        return_date = borrowing.return_date.strftime("%B %d, %Y %H:%M") if borrowing.return_date else "Not yet returned"
        
        # Determine status
        status = borrowing.status
        if status == 'Active' and borrowing.due_date < timezone.now():
            status = 'Overdue'

        context = {
            'borrowing': borrowing,
            'book_title': borrowing.book.title,
            'borrow_date': borrow_date,
            'due_date': due_date,
            'return_date': return_date,
            'status': status,
            'qr_code_image': qr_code_image
        }
        
        return render(request, 'main/show_borrowing_qrcode.html', context)
        
    except Borrowing.DoesNotExist:
        messages.error(request, 'Borrowing record not found.')
        return redirect('borrowing_history')
    except Exception as e:
        messages.error(request, f'Error generating QR code: {str(e)}')
        return redirect('borrowing_history')

@login_required
@user_passes_test(is_staff)
def qr_scan_view(request):
    return render(request, 'main/staff/qr_scan.html')

@login_required
@user_passes_test(is_staff)
def api_borrowing_detail(request, borrowing_id):
    try:
        borrowing = Borrowing.objects.select_related('book', 'borrower__user').get(id=borrowing_id)
        
        # Determine status based on dates
        status = borrowing.dynamic_status
        
        data = {
            'exists': True,
            'borrowing_id': borrowing.id,
            'book_title': borrowing.book.title,
            'borrower_name': borrowing.borrower.user.get_full_name() or borrowing.borrower.user.username,
            'borrow_date': borrowing.borrow_date.strftime("%B %d, %Y %H:%M") if borrowing.borrow_date else "Not yet borrowed",
            'due_date': borrowing.due_date.strftime("%B %d, %Y %H:%M"),
            'return_date': borrowing.return_date.strftime("%B %d, %Y %H:%M") if borrowing.return_date else "Not yet returned",
            'status': status,
            'penalty_amount': str(borrowing.calculated_penalty),
            'is_returned': borrowing.is_returned
        }
    except Borrowing.DoesNotExist:
        data = {'exists': False}
    return JsonResponse(data)

@login_required
@user_passes_test(is_staff)
def api_return_book(request, borrowing_id):
    if request.method == 'POST':
        try:
            borrowing = Borrowing.objects.get(id=borrowing_id)
            
            # Check if book is already returned
            if borrowing.is_returned:
                return JsonResponse({
                    'success': False,
                    'message': 'This book has already been returned.'
                })
            
            # Process the return
            borrowing.is_returned = True
            borrowing.return_date = timezone.now()
            
            # Set status and penalty from model properties
            borrowing.status = borrowing.dynamic_status
            borrowing.penalty_amount = borrowing.calculated_penalty
            
            # Update book availability
            book = borrowing.book
            book.available_quantity += 1
            
            # Save all changes in a transaction
            with transaction.atomic():
                book.save()
                borrowing.save()
            
            # Add success message
            messages.success(request, f'Book "{book.title}" has been returned successfully.')
            
            return JsonResponse({
                'success': True,
                'message': 'Book returned successfully!',
                'book_title': book.title,
                'return_date': borrowing.return_date.strftime("%B %d, %Y %H:%M"),
                'penalty_amount': str(borrowing.penalty_amount)
            })
            
        except Borrowing.DoesNotExist:
            return JsonResponse({
                'success': False,
                'message': 'Borrowing record not found.'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'Error processing return: {str(e)}'
            })
    
    return JsonResponse({
        'success': False,
        'message': 'Invalid request method.'
    })

@login_required
@user_passes_test(is_staff)
def api_confirm_borrow(request, borrowing_id):
    """API endpoint for confirming a book borrow."""
    if request.method == 'POST':
        try:
            borrowing = Borrowing.objects.select_related('book').get(id=borrowing_id)
            
            # Check if book is already borrowed
            if borrowing.status != 'Pending':
                return JsonResponse({
                    'success': False,
                    'message': 'This book is not in pending status.'
                })
            
            # Check if book is still available
            if borrowing.book.available_quantity <= 0:
                return JsonResponse({
                    'success': False,
                    'message': 'This book is no longer available.'
                })
            
            # Update borrowing status
            borrowing.status = 'Active'
            borrowing.borrow_date = timezone.now()
            borrowing.save()
            
            # Decrease book quantity
            book = borrowing.book
            book.available_quantity -= 1
            book.save()
            
            # Add success message
            messages.success(request, f'Book "{borrowing.book.title}" has been borrowed successfully.')
            
            return JsonResponse({
                'success': True,
                'message': 'Book borrowed successfully!',
                'book_title': borrowing.book.title,
                'borrow_date': borrowing.borrow_date.strftime("%B %d, %Y %H:%M")
            })
            
        except Borrowing.DoesNotExist:
            return JsonResponse({
                'success': False,
                'message': 'Borrowing record not found.'
            })
        except Exception as e:
            print(f"Error in api_confirm_borrow: {str(e)}")  # Add logging
            return JsonResponse({
                'success': False,
                'message': f'Error processing borrow: {str(e)}'
            })
    
    return JsonResponse({
        'success': False,
        'message': 'Invalid request method.'
    })

@csrf_exempt
@login_required
@user_passes_test(is_staff)
def upload_returns_csv(request):
    if request.method == 'POST' and request.FILES.get('csv_file'):
        csv_file = request.FILES['csv_file']
        
        # Check file extension
        if not csv_file.name.endswith('.csv'):
            messages.error(request, "Error: Please upload a valid CSV file. The file must have a .csv extension.")
            return redirect('return')
        
        # Check file size (limit to 10MB)
        if csv_file.size > 10 * 1024 * 1024:
            messages.error(request, "Error: File size too large. Please upload a CSV file smaller than 10MB.")
            return redirect('return')
        
        try:
            # Try to decode the file
            try:
                decoded_file = csv_file.read().decode('utf-8').splitlines()
            except UnicodeDecodeError:
                messages.error(request, "Error: Unable to read the CSV file. Please ensure the file is encoded in UTF-8 format.")
                return redirect('return')
            
            # Check if file is empty
            if not decoded_file:
                messages.error(request, "Error: The CSV file is empty. Please upload a file with data.")
                return redirect('return')
            
            reader = csv.DictReader(decoded_file)
            
            # Check if required columns exist
            required_columns = ['email', 'book_title']
            missing_columns = [col for col in required_columns if col not in reader.fieldnames]
            if missing_columns:
                messages.error(request, f"Error: Missing required columns in CSV: {', '.join(missing_columns)}. Required columns: {', '.join(required_columns)}")
                return redirect('return')
            
            updated = 0
            errors = []
            row_number = 1  # Start from 1 for user-friendly error messages
            
            for row in reader:
                row_number += 1
                try:
                    # Validate required fields
                    email = row.get('email', '').strip()
                    if not email:
                        errors.append(f"Row {row_number}: Email is required")
                        continue
                    
                    book_title = row.get('book_title', '').strip()
                    if not book_title:
                        errors.append(f"Row {row_number}: Book title is required")
                        continue
                    
                    # Validate email format
                    if '@' not in email or '.' not in email:
                        errors.append(f"Row {row_number}: Invalid email format '{email}'")
                        continue
                    
                    # --- Borrower/User ---
                    borrower = None
                    user = None
                    
                    try:
                        user = User.objects.filter(email=email).first()
                        if not user:
                            # Create user
                            username = email.split('@')[0]
                            # Ensure username is unique
                            base_username = username
                            counter = 1
                            while User.objects.filter(username=username).exists():
                                username = f"{base_username}{counter}"
                                counter += 1
                            
                            user = User.objects.create_user(
                                username=username,
                                email=email,
                                password=row.get('password', 'Password123'),
                                first_name=row.get('first_name', '').strip(),
                                last_name=row.get('last_name', '').strip()
                            )
                    except Exception as e:
                        errors.append(f"Row {row_number}: Error creating user - {str(e)}")
                        continue
                    
                    try:
                        from .models import Borrower, Book, Borrowing
                        borrower = Borrower.objects.filter(user=user).first()
                        if not borrower:
                            # Validate user_type
                            user_type = row.get('user_type', 'STUDENT').strip().upper()
                            valid_user_types = ['STUDENT', 'TEACHER', 'STAFF']
                            if user_type not in valid_user_types:
                                errors.append(f"Row {row_number}: Invalid user_type '{user_type}'. Valid types: {', '.join(valid_user_types)}")
                                continue
                            
                            borrower = Borrower.objects.create(
                                user=user,
                                id_number=row.get('id_number', '').strip(),
                                phone_number=row.get('phone_number', '').strip(),
                                address=row.get('address', '').strip(),
                                year_level=row.get('year_level', '').strip(),
                                section=row.get('section', '').strip(),
                                course=row.get('course', '').strip(),
                                department=row.get('department', '').strip(),
                                user_type=user_type
                            )
                    except Exception as e:
                        errors.append(f"Row {row_number}: Error creating borrower - {str(e)}")
                        continue
                    
                    # --- Book ---
                    book = None
                    book_id = row.get('book_id')
                    
                    try:
                        if book_id and str(book_id).isdigit():
                            book = Book.objects.filter(id=book_id).first()
                        
                        if not book:
                            # Try by title
                            book = Book.objects.filter(title=book_title).first()
                        
                        if not book:
                            # Create book if it doesn't exist
                            author = row.get('author', '').strip()
                            if not author:
                                errors.append(f"Row {row_number}: Author is required when creating new book")
                                continue
                            
                            # Validate category
                            category = row.get('category', '').strip()
                            if category and category not in dict(Book.CATEGORY_CHOICES):
                                valid_categories = ', '.join([cat[0] for cat in Book.CATEGORY_CHOICES])
                                errors.append(f"Row {row_number}: Invalid category '{category}'. Valid categories: {valid_categories}")
                                continue
                            
                            # Validate quantity
                            quantity = row.get('available_quantity', 1)
                            try:
                                quantity = int(quantity) if quantity else 1
                                if quantity < 0:
                                    errors.append(f"Row {row_number}: Quantity cannot be negative")
                                    continue
                            except ValueError:
                                errors.append(f"Row {row_number}: Invalid quantity value '{quantity}'. Must be a number.")
                                continue
                            
                            book = Book.objects.create(
                                title=book_title,
                                author=author,
                                isbn=row.get('isbn', '').strip(),
                                category=category or 'fiction',
                                description=row.get('description', '').strip(),
                                quantity=quantity,
                                available_quantity=quantity,
                                cover_image_url=row.get('cover_image_url', '').strip()
                            )
                    except Exception as e:
                        errors.append(f"Row {row_number}: Error with book - {str(e)}")
                        continue
                    
                    # --- Borrowing ---
                    borrowing_id = row.get('borrowing_id')
                    
                    try:
                        if borrowing_id and str(borrowing_id).isdigit():
                            try:
                                borrowing = Borrowing.objects.get(id=borrowing_id)
                                # Update existing borrowing
                                borrowing.return_date = row.get('return_date') or None
                                borrowing.borrow_date = row.get('borrow_date') or None
                                borrowing.due_date = row.get('due_date') or None
                                
                                if borrowing.return_date:
                                    borrowing.status = "Returned"
                                elif borrowing.borrow_date and borrowing.due_date:
                                    borrowing.status = "Active"
                                else:
                                    borrowing.status = "Pending"
                                
                                borrowing.is_returned = bool(borrowing.return_date)
                                
                                # Validate penalty amount
                                penalty_amount = row.get('penalty_amount', 0)
                                try:
                                    penalty_amount = float(penalty_amount) if penalty_amount else 0
                                    if penalty_amount < 0:
                                        errors.append(f"Row {row_number}: Penalty amount cannot be negative")
                                        continue
                                    borrowing.penalty_amount = penalty_amount
                                except ValueError:
                                    errors.append(f"Row {row_number}: Invalid penalty amount '{penalty_amount}'. Must be a number.")
                                    continue
                                
                                borrowing.save()
                                updated += 1
                                continue  # Go to next row after update
                            except Borrowing.DoesNotExist:
                                pass  # Fall through to create new
                        
                        # Create new borrowing
                        borrow_date = row.get('borrow_date') or None
                        due_date = row.get('due_date') or None
                        return_date = row.get('return_date') or None
                        
                        # Validate dates if provided
                        if borrow_date:
                            try:
                                from datetime import datetime
                                datetime.strptime(borrow_date, '%Y-%m-%d')
                            except ValueError:
                                errors.append(f"Row {row_number}: Invalid borrow_date format '{borrow_date}'. Use YYYY-MM-DD format.")
                                continue
                        
                        if due_date:
                            try:
                                from datetime import datetime
                                datetime.strptime(due_date, '%Y-%m-%d')
                            except ValueError:
                                errors.append(f"Row {row_number}: Invalid due_date format '{due_date}'. Use YYYY-MM-DD format.")
                                continue
                        
                        if return_date:
                            try:
                                from datetime import datetime
                                datetime.strptime(return_date, '%Y-%m-%d')
                            except ValueError:
                                errors.append(f"Row {row_number}: Invalid return_date format '{return_date}'. Use YYYY-MM-DD format.")
                                continue
                        
                        if return_date:
                            status = "Returned"
                        elif borrow_date and due_date:
                            status = "Active"
                        else:
                            status = "Pending"
                        
                        # Validate penalty amount
                        penalty_amount = row.get('penalty_amount', 0)
                        try:
                            penalty_amount = float(penalty_amount) if penalty_amount else 0
                            if penalty_amount < 0:
                                errors.append(f"Row {row_number}: Penalty amount cannot be negative")
                                continue
                        except ValueError:
                            errors.append(f"Row {row_number}: Invalid penalty amount '{penalty_amount}'. Must be a number.")
                            continue
                        
                        new_borrowing = Borrowing.objects.create(
                            book=book,
                            borrower=borrower,
                            borrow_date=borrow_date,
                            due_date=due_date,
                            return_date=return_date,
                            is_returned=bool(return_date),
                            penalty_amount=penalty_amount,
                            status=status
                        )
                        updated += 1
                        
                    except Exception as e:
                        errors.append(f"Row {row_number}: Error creating/updating borrowing - {str(e)}")
                        continue
                        
                except Exception as e:
                    errors.append(f"Row {row_number}: Unexpected error - {str(e)}")
                    continue
            
            # Show results
            if updated > 0:
                messages.success(request, f"Successfully processed {updated} returns.")
            
            if errors:
                error_message = f"Upload completed with {len(errors)} errors:\n" + "\n".join(errors[:10])  # Show first 10 errors
                if len(errors) > 10:
                    error_message += f"\n... and {len(errors) - 10} more errors"
                messages.error(request, error_message)
            
            if updated == 0 and errors:
                messages.error(request, "No returns were processed due to errors. Please check the CSV file and try again.")
                
        except csv.Error as e:
            messages.error(request, f"Error reading CSV file: {str(e)}. Please check the file format.")
        except Exception as e:
            messages.error(request, f"Unexpected error during upload: {str(e)}. Please try again.")
    else:
        messages.error(request, "Error: Please upload a valid CSV file.")
    return redirect('return')

@login_required
@user_passes_test(is_staff)
def view_borrowing(request, borrowing_id):
    try:
        borrowing = get_object_or_404(Borrowing, id=borrowing_id)
        
        # Calculate current penalty
        current_penalty = calculate_penalty(borrowing.due_date, borrowing.return_date)
        
        context = {
            'page_title': 'View Borrowing',
            'borrowing': borrowing,
            'now': timezone.now(),
            'current_penalty': current_penalty
        }
        return render(request, 'main/staff/view_borrowing.html', context)
    except Exception as e:
        messages.error(request, f'Error viewing borrowing: {str(e)}')
        return redirect('borrowing')

@login_required
@user_passes_test(is_staff)
def edit_borrowing(request, borrowing_id):
    try:
        borrowing = get_object_or_404(Borrowing, id=borrowing_id)
        now = timezone.now()
        
        if request.method == 'POST':
            form = BorrowingForm(request.POST, instance=borrowing)
            if form.is_valid():
                updated_borrowing = form.save(commit=False)

                # Set status and penalty from model properties before saving
                updated_borrowing.status = updated_borrowing.dynamic_status
                if updated_borrowing.status in ['Late Return', 'Overdue']:
                    updated_borrowing.penalty_amount = updated_borrowing.calculated_penalty
                elif updated_borrowing.status == 'Returned':
                    updated_borrowing.penalty_amount = 0

                updated_borrowing.save()
                messages.success(request, 'Borrowing record updated successfully.')
                return redirect('view_borrowing', borrowing_id=borrowing.id)
        else:
            form = BorrowingForm(instance=borrowing)
        
        # Calculate days overdue/late and current penalty
        is_late_return = borrowing.is_returned and borrowing.return_date and borrowing.return_date > borrowing.due_date
        
        # Calculate days overdue (for active borrowings) or days late (for returned borrowings)
        if borrowing.is_returned and borrowing.return_date:
            days_late = (borrowing.return_date.date() - borrowing.due_date.date()).days
            days_overdue = 0
        else:
            days_late = 0
            days_overdue = max(0, (now.date() - borrowing.due_date.date()).days)
        
        # Calculate current penalty
        if borrowing.is_returned:
            current_penalty = calculate_penalty(borrowing.due_date, borrowing.return_date)
        else:
            current_penalty = calculate_penalty(borrowing.due_date, now)
        
        context = {
            'page_title': 'Edit Borrowing',
            'borrowing': borrowing,
            'borrowing_id': borrowing_id,
            'form': form,
            'is_late_return': is_late_return,
            'days_overdue': days_overdue,
            'days_late': days_late,
            'current_penalty': current_penalty,
            'now': now
        }
        return render(request, 'main/staff/edit_borrowing.html', context)
    except Exception as e:
        messages.error(request, f'Error editing borrowing: {str(e)}')
        return redirect('borrowing')

@login_required
@user_passes_test(is_staff)
def borrowing(request):
    """View for managing borrowings"""
    search_query = request.GET.get('q')
    status_filter = request.GET.get('status_filter')
    borrower_type = request.GET.get('borrower_type')
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    
    # Start with active borrowings only (exclude returned and late return)
    borrowings = Borrowing.objects.filter(
        ~Q(status__in=['Returned', 'Late Return']),
        is_returned=False
    ).select_related('book', 'borrower__user')
    
    # Apply search filter
    if search_query:
        borrowings = borrowings.filter(
            Q(book__title__icontains=search_query) |
            Q(borrower__user__first_name__icontains=search_query) |
            Q(borrower__user__last_name__icontains=search_query)
        )
    
    # Apply status filter
    if status_filter:
        if status_filter == 'active':
            # Active but not overdue
            borrowings = borrowings.filter(status='Active', due_date__gte=timezone.now())
        elif status_filter == 'overdue':
            # Overdue and not returned
            borrowings = borrowings.filter(due_date__lt=timezone.now(), is_returned=False)
        elif status_filter == 'pending':
            borrowings = borrowings.filter(status='Pending')
    
    # Apply borrower type filter
    if borrower_type:
        borrowings = borrowings.filter(borrower__user_type=borrower_type)
    
    # Apply date filters
    if start_date:
        borrowings = borrowings.filter(borrow_date__gte=start_date)
    if end_date:
        borrowings = borrowings.filter(borrow_date__lte=end_date)
    
    # Get all borrower types for the filter dropdown
    borrower_types = Borrower.USER_TYPE_CHOICES
    
    context = {
        'page_title': 'Borrowings Management',
        'borrowings': borrowings,
        'search_query': search_query,
        'selected_status': status_filter,
        'selected_borrower_type': borrower_type,
        'selected_start_date': start_date,
        'selected_end_date': end_date,
        'borrower_types': borrower_types,
        'now': timezone.now()  # Add current time to context
    }
    
    return render(request, 'main/staff/borrowings_management.html', context)
