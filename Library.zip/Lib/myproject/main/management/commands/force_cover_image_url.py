from django.core.management.base import BaseCommand
from main.models import Book

class Command(BaseCommand):
    help = 'Force set the cover_image_url for a Book by its ID and clear the cover_image file field.'

    def add_arguments(self, parser):
        parser.add_argument('book_id', type=int, help='ID of the book to update')
        parser.add_argument('url', type=str, help='The new cover image URL')

    def handle(self, *args, **options):
        book_id = options['book_id']
        url = options['url']
        try:
            book = Book.objects.get(id=book_id)
            book.cover_image_url = url
            book.cover_image = None  # Clear any uploaded file
            book.save()
            self.stdout.write(self.style.SUCCESS(f'Force-set cover_image_url for book ID {book_id}'))
        except Book.DoesNotExist:
            self.stdout.write(self.style.ERROR(f'Book with ID {book_id} does not exist')) 