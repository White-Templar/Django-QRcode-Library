from django.core.management.base import BaseCommand
from main.models import Borrowing

class Command(BaseCommand):
    help = 'Fix Borrowing records: set status="Returned" and is_returned=True for all with a return_date.'

    def handle(self, *args, **options):
        qs = Borrowing.objects.filter(return_date__isnull=False).exclude(status="Returned")
        count = qs.count()
        qs.update(status="Returned", is_returned=True)
        self.stdout.write(self.style.SUCCESS(f"Updated {count} borrowings to status='Returned' and is_returned=True.")) 