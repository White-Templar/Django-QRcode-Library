from django.db import models
from django.contrib.auth.models import User
import uuid
from datetime import datetime, timedelta
from django.utils.timezone import now as django_now

class Book(models.Model):
    CATEGORY_CHOICES = [
        ('science', 'Science'),
        ('art', 'Art'),
        ('technology', 'Technology'),
        ('history', 'History'),
        ('fiction', 'Fiction'),
    ]

    title = models.CharField(max_length=200)
    author = models.CharField(max_length=200)
    isbn = models.CharField(max_length=13, unique=True, blank=True)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    description = models.TextField()
    quantity = models.IntegerField(default=1)
    available_quantity = models.IntegerField(default=1)
    cover_image = models.ImageField(upload_to='', null=True, blank=True)
    cover_image_url = models.URLField(max_length=500, null=True, blank=True)
    date_added = models.DateTimeField(auto_now_add=True)
    last_modified = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if not self.isbn:
            # Generate a unique ISBN if not provided
            self.isbn = str(uuid.uuid4().int)[:13]
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.title} by {self.author}"

class Borrower(models.Model):
    USER_TYPE_CHOICES = [
        ('STUDENT', 'Student'),
        ('TEACHER', 'Teacher'),
        ('STAFF', 'Staff'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    user_type = models.CharField(max_length=20, choices=USER_TYPE_CHOICES)
    id_number = models.CharField(max_length=50, unique=True)
    phone_number = models.CharField(max_length=20)
    address = models.TextField()
    date_registered = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    
    # Student-specific fields
    year_level = models.CharField(max_length=2, null=True, blank=True)
    section = models.CharField(max_length=10, null=True, blank=True)
    course = models.CharField(max_length=50, null=True, blank=True)
    
    # Staff/Teacher-specific fields
    department = models.CharField(max_length=50, null=True, blank=True)

    def __str__(self):
        return f"{self.user.get_full_name()} ({self.user_type})"

class Borrowing(models.Model):
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Active', 'Active'),
        ('Returned', 'Returned'),
        ('Overdue', 'Overdue'),
        ('Late Return', 'Late Return'),
    ]
    
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    borrower = models.ForeignKey(Borrower, on_delete=models.CASCADE)
    borrow_date = models.DateTimeField(null=True, blank=True)  # Changed to allow null
    due_date = models.DateTimeField()
    return_date = models.DateTimeField(null=True, blank=True)
    is_returned = models.BooleanField(default=False)
    penalty_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    notes = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')

    @property
    def dynamic_status(self):
        if self.is_returned:
            if self.return_date and self.due_date and self.return_date > self.due_date:
                return 'Late Return'
            return 'Returned'
        if not self.is_returned and self.due_date < django_now():
            return 'Overdue'
        if self.status == 'Pending':
            return 'Pending'
        return 'Active'

    @property
    def calculated_penalty(self):
        """Calculates the penalty for an overdue or late return."""
        status = self.dynamic_status
        if status not in ['Overdue', 'Late Return']:
            return 0
        
        end_date = self.return_date if self.is_returned else django_now()
        
        if not self.due_date or end_date.date() <= self.due_date.date():
            return 0

        # Add 1 to include the due date in the penalty calculation
        days_overdue = (end_date.date() - self.due_date.date()).days + 1
        return max(0, days_overdue) * 50

    def save(self, *args, **kwargs):
        if not self.due_date:
            # Set default due date to 14 days from borrow date
            self.due_date = django_now() + timedelta(days=14)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.borrower} borrowed {self.book}"

class Reservation(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    borrower = models.ForeignKey(Borrower, on_delete=models.CASCADE)
    reservation_date = models.DateTimeField(auto_now_add=True)
    pickup_date = models.DateTimeField(null=True, blank=True)
    expiry_date = models.DateTimeField()
    is_fulfilled = models.BooleanField(default=False)
    is_expired = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        if not self.id:
            if self.pickup_date:
                self.expiry_date = self.pickup_date + timedelta(days=1)
            else:
                self.expiry_date = django_now() + timedelta(days=3)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.borrower} reserved {self.book}"

class Bookmark(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    date_added = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'book')

    def __str__(self):
        return f"{self.user.username} bookmarked {self.book.title}"
